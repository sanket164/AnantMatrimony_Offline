﻿namespace AnantMatrimony.FORMS
{
    partial class frmMemberMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblMemberCode = new System.Windows.Forms.Label();
            this.txtProfileCreatedByCode = new System.Windows.Forms.TextBox();
            this.cmbmStatus = new System.Windows.Forms.ComboBox();
            this.dtpRegisterDate = new System.Windows.Forms.DateTimePicker();
            this.cmbisActive = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.rdbtnMale = new System.Windows.Forms.RadioButton();
            this.rdbtnFemale = new System.Windows.Forms.RadioButton();
            this.txtProfileCreatedBy = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.dtpDateofBirth = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMemberName = new System.Windows.Forms.TextBox();
            this.lblMemberName = new System.Windows.Forms.Label();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnSave_MemberDtl = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtWorkingStateCityCode = new System.Windows.Forms.TextBox();
            this.txtOccupationCode = new System.Windows.Forms.TextBox();
            this.txtEducationCode = new System.Windows.Forms.TextBox();
            this.txtOccupationDtls = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.txtDegree = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtWorkAddress = new System.Windows.Forms.TextBox();
            this.txtOccupation = new System.Windows.Forms.TextBox();
            this.txtEducation = new System.Windows.Forms.TextBox();
            this.ddlAnnualIncomeCurrency = new System.Windows.Forms.ComboBox();
            this.label103 = new System.Windows.Forms.Label();
            this.ddlAnnualIncome = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ddlLandlineNo1_Rel = new System.Windows.Forms.ComboBox();
            this.label99 = new System.Windows.Forms.Label();
            this.txtVisaCountryCode = new System.Windows.Forms.TextBox();
            this.txtVisaStatusCode = new System.Windows.Forms.TextBox();
            this.txtStateCityCode = new System.Windows.Forms.TextBox();
            this.txtCountryCode = new System.Windows.Forms.TextBox();
            this.ddlMobileNo1_Rel = new System.Windows.Forms.ComboBox();
            this.ddlMobileNo_Rel = new System.Windows.Forms.ComboBox();
            this.txtMobileNo = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.chkChangePassword = new System.Windows.Forms.CheckBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtHomeAddress1 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtHomeAddress2 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtLandlineNo1 = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.txtMobileNo1 = new System.Windows.Forms.TextBox();
            this.txtStateCity = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtVisaStatus = new System.Windows.Forms.TextBox();
            this.txtEmailID = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.txtVisaCountry = new System.Windows.Forms.TextBox();
            this.txtSecondaryEmailID = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.txtLandlineNo = new System.Windows.Forms.TextBox();
            this.ddlMobileNo2_Rel = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmbBirthPlace = new System.Windows.Forms.ComboBox();
            this.ddlMaritalStatus = new System.Windows.Forms.ComboBox();
            this.txtBloodGroupCode = new System.Windows.Forms.TextBox();
            this.txtSubCasteCode = new System.Windows.Forms.TextBox();
            this.txtCasteCode = new System.Windows.Forms.TextBox();
            this.dtpTime = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ddlNoOfChildren = new System.Windows.Forms.ComboBox();
            this.ddlLiveChildrenTogether = new System.Windows.Forms.ComboBox();
            this.label90 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtCaste = new System.Windows.Forms.TextBox();
            this.txtSubCaste = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ddlHeight = new System.Windows.Forms.ComboBox();
            this.pnlManglik = new System.Windows.Forms.Panel();
            this.rdbtnManglikDontKnow = new System.Windows.Forms.RadioButton();
            this.rdbtnManglikNo = new System.Windows.Forms.RadioButton();
            this.rdbtnManglikYes = new System.Windows.Forms.RadioButton();
            this.label23 = new System.Windows.Forms.Label();
            this.txtBloodGroup = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnSave_FamilyDtl = new System.Windows.Forms.Button();
            this.txtFileNote = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtChoice = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtAboutInfo = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvSiblingDetails = new AnantMatrimony.CustomizeGrid();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtMotherOccupation = new System.Windows.Forms.TextBox();
            this.txtFatherOccupation = new System.Windows.Forms.TextBox();
            this.txtNativePlace = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtMosalPlace = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtMotherName = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtFatherName = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnSave_PartnerPref = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.ddlPHeightTo = new System.Windows.Forms.ComboBox();
            this.ddlPAgeTo = new System.Windows.Forms.ComboBox();
            this.ddlPHeightFrom = new System.Windows.Forms.ComboBox();
            this.ddlPAgeFrom = new System.Windows.Forms.ComboBox();
            this.chkPWorkingWith = new System.Windows.Forms.CheckedListBox();
            this.chkPOccupation = new System.Windows.Forms.CheckedListBox();
            this.chkPEducation = new System.Windows.Forms.CheckedListBox();
            this.chkPVisaStatus = new System.Windows.Forms.CheckedListBox();
            this.chkPCountryLivingIn = new System.Windows.Forms.CheckedListBox();
            this.chkPMaritalStatus = new System.Windows.Forms.CheckedListBox();
            this.label108 = new System.Windows.Forms.Label();
            this.ddlPAnnualIncomeCurrency = new System.Windows.Forms.ComboBox();
            this.ddlPAnnualIncome = new System.Windows.Forms.ComboBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbPHaveChildrens = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.chkPCaste = new System.Windows.Forms.CheckedListBox();
            this.pnlPManglik = new System.Windows.Forms.Panel();
            this.rdbtnPManglikDontKnow = new System.Windows.Forms.RadioButton();
            this.rdbtnPManglikNo = new System.Windows.Forms.RadioButton();
            this.rdbtnPManglikYes = new System.Windows.Forms.RadioButton();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtAboutPartner = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnAddPhoto = new System.Windows.Forms.Button();
            this.flMemberPhotos = new System.Windows.Forms.FlowLayoutPanel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblSrNo = new System.Windows.Forms.Label();
            this.btnAddMemberShip = new System.Windows.Forms.Button();
            this.txtBankBranch = new System.Windows.Forms.TextBox();
            this.dtpChaqueDate = new System.Windows.Forms.DateTimePicker();
            this.txtChaqueNo = new System.Windows.Forms.TextBox();
            this.ddlPayBy = new System.Windows.Forms.ComboBox();
            this.txtAmountReceived = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.updwnMembershipMonth = new System.Windows.Forms.NumericUpDown();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpJoinDate = new System.Windows.Forms.DateTimePicker();
            this.txtMemberShipTypeCode = new System.Windows.Forms.TextBox();
            this.txtMemberShipType = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgvMemershipDetails = new AnantMatrimony.CustomizeGrid();
            this.pnlErrorMsg = new System.Windows.Forms.Panel();
            this.picMsg = new System.Windows.Forms.PictureBox();
            this.lblMsg = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.pnlManglik.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSiblingDetails)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.pnlPManglik.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updwnMembershipMonth)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMemershipDetails)).BeginInit();
            this.pnlErrorMsg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMsg)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblMemberCode);
            this.panel1.Controls.Add(this.txtProfileCreatedByCode);
            this.panel1.Controls.Add(this.cmbmStatus);
            this.panel1.Controls.Add(this.dtpRegisterDate);
            this.panel1.Controls.Add(this.cmbisActive);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.rdbtnMale);
            this.panel1.Controls.Add(this.rdbtnFemale);
            this.panel1.Controls.Add(this.txtProfileCreatedBy);
            this.panel1.Controls.Add(this.label102);
            this.panel1.Controls.Add(this.dtpDateofBirth);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtMemberName);
            this.panel1.Controls.Add(this.lblMemberName);
            this.panel1.Location = new System.Drawing.Point(11, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(897, 81);
            this.panel1.TabIndex = 0;
            // 
            // lblMemberCode
            // 
            this.lblMemberCode.AutoSize = true;
            this.lblMemberCode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMemberCode.Location = new System.Drawing.Point(787, 57);
            this.lblMemberCode.Name = "lblMemberCode";
            this.lblMemberCode.Size = new System.Drawing.Size(93, 14);
            this.lblMemberCode.TabIndex = 328;
            this.lblMemberCode.Text = "MemberCode";
            // 
            // txtProfileCreatedByCode
            // 
            this.txtProfileCreatedByCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProfileCreatedByCode.Location = new System.Drawing.Point(385, 27);
            this.txtProfileCreatedByCode.Name = "txtProfileCreatedByCode";
            this.txtProfileCreatedByCode.Size = new System.Drawing.Size(13, 22);
            this.txtProfileCreatedByCode.TabIndex = 327;
            this.txtProfileCreatedByCode.Tag = "*ProfileCreatedByCode";
            this.txtProfileCreatedByCode.Visible = false;
            // 
            // cmbmStatus
            // 
            this.cmbmStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbmStatus.FormattingEnabled = true;
            this.cmbmStatus.Items.AddRange(new object[] {
            "W - Website",
            "E - Email",
            "P - Personal",
            "K - Kankukanya",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "Demo User"});
            this.cmbmStatus.Location = new System.Drawing.Point(245, 3);
            this.cmbmStatus.Name = "cmbmStatus";
            this.cmbmStatus.Size = new System.Drawing.Size(139, 22);
            this.cmbmStatus.TabIndex = 1;
            this.cmbmStatus.Tag = "nonRegistration From";
            // 
            // dtpRegisterDate
            // 
            this.dtpRegisterDate.CustomFormat = "dd/MM/yyyy";
            this.dtpRegisterDate.Enabled = false;
            this.dtpRegisterDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRegisterDate.Location = new System.Drawing.Point(767, 3);
            this.dtpRegisterDate.Name = "dtpRegisterDate";
            this.dtpRegisterDate.Size = new System.Drawing.Size(115, 22);
            this.dtpRegisterDate.TabIndex = 5;
            this.dtpRegisterDate.Tag = "RegisterDate";
            // 
            // cmbisActive
            // 
            this.cmbisActive.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbisActive.FormattingEnabled = true;
            this.cmbisActive.Items.AddRange(new object[] {
            "New / Un-Approved",
            "Active",
            "Updated",
            "Done",
            "Block",
            "Deleted"});
            this.cmbisActive.Location = new System.Drawing.Point(146, 3);
            this.cmbisActive.Name = "cmbisActive";
            this.cmbisActive.Size = new System.Drawing.Size(93, 22);
            this.cmbisActive.TabIndex = 0;
            this.cmbisActive.Tag = "nonProfile Status";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(659, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(106, 14);
            this.label21.TabIndex = 308;
            this.label21.Text = "Register Date :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(37, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(106, 14);
            this.label20.TabIndex = 307;
            this.label20.Text = "Profile Status :";
            // 
            // rdbtnMale
            // 
            this.rdbtnMale.AutoSize = true;
            this.rdbtnMale.Location = new System.Drawing.Point(528, 31);
            this.rdbtnMale.Name = "rdbtnMale";
            this.rdbtnMale.Size = new System.Drawing.Size(54, 18);
            this.rdbtnMale.TabIndex = 6;
            this.rdbtnMale.TabStop = true;
            this.rdbtnMale.Text = "Male";
            this.rdbtnMale.UseVisualStyleBackColor = true;
            // 
            // rdbtnFemale
            // 
            this.rdbtnFemale.AutoSize = true;
            this.rdbtnFemale.Location = new System.Drawing.Point(582, 31);
            this.rdbtnFemale.Name = "rdbtnFemale";
            this.rdbtnFemale.Size = new System.Drawing.Size(70, 18);
            this.rdbtnFemale.TabIndex = 7;
            this.rdbtnFemale.TabStop = true;
            this.rdbtnFemale.Text = "Female";
            this.rdbtnFemale.UseVisualStyleBackColor = true;
            // 
            // txtProfileCreatedBy
            // 
            this.txtProfileCreatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProfileCreatedBy.Location = new System.Drawing.Point(146, 27);
            this.txtProfileCreatedBy.Name = "txtProfileCreatedBy";
            this.txtProfileCreatedBy.Size = new System.Drawing.Size(237, 22);
            this.txtProfileCreatedBy.TabIndex = 2;
            this.txtProfileCreatedBy.Tag = "%ProfileCreatedBy";
            this.txtProfileCreatedBy.Validating += new System.ComponentModel.CancelEventHandler(this.txtProfileCreatedBy_Validating);
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(5, 31);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(137, 14);
            this.label102.TabIndex = 306;
            this.label102.Text = "Profile Created By :";
            // 
            // dtpDateofBirth
            // 
            this.dtpDateofBirth.CustomFormat = "dd/MM/yyyy";
            this.dtpDateofBirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateofBirth.Location = new System.Drawing.Point(530, 3);
            this.dtpDateofBirth.Name = "dtpDateofBirth";
            this.dtpDateofBirth.Size = new System.Drawing.Size(122, 22);
            this.dtpDateofBirth.TabIndex = 4;
            this.dtpDateofBirth.Tag = "DateofBirth";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(407, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 14);
            this.label2.TabIndex = 304;
            this.label2.Text = "Date of Birth :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(440, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 14);
            this.label1.TabIndex = 302;
            this.label1.Text = "Gender :";
            // 
            // txtMemberName
            // 
            this.txtMemberName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMemberName.Location = new System.Drawing.Point(146, 53);
            this.txtMemberName.Name = "txtMemberName";
            this.txtMemberName.Size = new System.Drawing.Size(239, 22);
            this.txtMemberName.TabIndex = 3;
            this.txtMemberName.Tag = "MemberName";
            this.txtMemberName.Validating += new System.ComponentModel.CancelEventHandler(this.txtMemberName_Validating);
            // 
            // lblMemberName
            // 
            this.lblMemberName.AutoSize = true;
            this.lblMemberName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMemberName.Location = new System.Drawing.Point(18, 57);
            this.lblMemberName.Name = "lblMemberName";
            this.lblMemberName.Size = new System.Drawing.Size(124, 14);
            this.lblMemberName.TabIndex = 300;
            this.lblMemberName.Text = "Candidate Name :";
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPage1);
            this.tabMain.Controls.Add(this.tabPage2);
            this.tabMain.Controls.Add(this.tabPage3);
            this.tabMain.Controls.Add(this.tabPage4);
            this.tabMain.Controls.Add(this.tabPage5);
            this.tabMain.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMain.Location = new System.Drawing.Point(11, 88);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(897, 485);
            this.tabMain.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnSave_MemberDtl);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.label40);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.label29);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(889, 458);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Member Details";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnSave_MemberDtl
            // 
            this.btnSave_MemberDtl.Location = new System.Drawing.Point(731, 424);
            this.btnSave_MemberDtl.Name = "btnSave_MemberDtl";
            this.btnSave_MemberDtl.Size = new System.Drawing.Size(94, 31);
            this.btnSave_MemberDtl.TabIndex = 322;
            this.btnSave_MemberDtl.Text = "Save";
            this.btnSave_MemberDtl.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label28.Location = new System.Drawing.Point(17, 2);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(100, 16);
            this.label28.TabIndex = 63;
            this.label28.Text = "Basic Details";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label40.Location = new System.Drawing.Point(17, 322);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(169, 16);
            this.label40.TabIndex = 321;
            this.label40.Text = "Education && Profession";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtWorkingStateCityCode);
            this.groupBox6.Controls.Add(this.txtOccupationCode);
            this.groupBox6.Controls.Add(this.txtEducationCode);
            this.groupBox6.Controls.Add(this.txtOccupationDtls);
            this.groupBox6.Controls.Add(this.label45);
            this.groupBox6.Controls.Add(this.txtDegree);
            this.groupBox6.Controls.Add(this.label44);
            this.groupBox6.Controls.Add(this.txtWorkAddress);
            this.groupBox6.Controls.Add(this.txtOccupation);
            this.groupBox6.Controls.Add(this.txtEducation);
            this.groupBox6.Controls.Add(this.ddlAnnualIncomeCurrency);
            this.groupBox6.Controls.Add(this.label103);
            this.groupBox6.Controls.Add(this.ddlAnnualIncome);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Controls.Add(this.label37);
            this.groupBox6.Controls.Add(this.label41);
            this.groupBox6.Location = new System.Drawing.Point(11, 325);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(860, 96);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            // 
            // txtWorkingStateCityCode
            // 
            this.txtWorkingStateCityCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtWorkingStateCityCode.Location = new System.Drawing.Point(408, 58);
            this.txtWorkingStateCityCode.Name = "txtWorkingStateCityCode";
            this.txtWorkingStateCityCode.Size = new System.Drawing.Size(13, 22);
            this.txtWorkingStateCityCode.TabIndex = 334;
            this.txtWorkingStateCityCode.Tag = "";
            this.txtWorkingStateCityCode.Visible = false;
            // 
            // txtOccupationCode
            // 
            this.txtOccupationCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOccupationCode.Location = new System.Drawing.Point(408, 38);
            this.txtOccupationCode.Name = "txtOccupationCode";
            this.txtOccupationCode.Size = new System.Drawing.Size(13, 22);
            this.txtOccupationCode.TabIndex = 333;
            this.txtOccupationCode.Tag = "*Occupation";
            this.txtOccupationCode.Visible = false;
            // 
            // txtEducationCode
            // 
            this.txtEducationCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEducationCode.Location = new System.Drawing.Point(408, 17);
            this.txtEducationCode.Name = "txtEducationCode";
            this.txtEducationCode.Size = new System.Drawing.Size(13, 22);
            this.txtEducationCode.TabIndex = 332;
            this.txtEducationCode.Tag = "*Education";
            this.txtEducationCode.Visible = false;
            // 
            // txtOccupationDtls
            // 
            this.txtOccupationDtls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOccupationDtls.Location = new System.Drawing.Point(578, 37);
            this.txtOccupationDtls.Name = "txtOccupationDtls";
            this.txtOccupationDtls.Size = new System.Drawing.Size(238, 22);
            this.txtOccupationDtls.TabIndex = 4;
            this.txtOccupationDtls.Tag = "OccupationDtls";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(417, 41);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(140, 14);
            this.label45.TabIndex = 303;
            this.label45.Text = "Occupation Details :";
            // 
            // txtDegree
            // 
            this.txtDegree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDegree.Location = new System.Drawing.Point(578, 16);
            this.txtDegree.Name = "txtDegree";
            this.txtDegree.Size = new System.Drawing.Size(238, 22);
            this.txtDegree.TabIndex = 3;
            this.txtDegree.Tag = "Degree";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(493, 20);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(64, 14);
            this.label44.TabIndex = 302;
            this.label44.Text = "Degree :";
            // 
            // txtWorkAddress
            // 
            this.txtWorkAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtWorkAddress.Location = new System.Drawing.Point(170, 58);
            this.txtWorkAddress.Name = "txtWorkAddress";
            this.txtWorkAddress.Size = new System.Drawing.Size(238, 22);
            this.txtWorkAddress.TabIndex = 2;
            this.txtWorkAddress.Tag = "nontxtWorking City";
            this.txtWorkAddress.Validating += new System.ComponentModel.CancelEventHandler(this.txtWorkAddress_Validating);
            // 
            // txtOccupation
            // 
            this.txtOccupation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOccupation.Location = new System.Drawing.Point(170, 37);
            this.txtOccupation.Name = "txtOccupation";
            this.txtOccupation.Size = new System.Drawing.Size(238, 22);
            this.txtOccupation.TabIndex = 1;
            this.txtOccupation.Tag = "nontxtOccupation";
            this.txtOccupation.Validating += new System.ComponentModel.CancelEventHandler(this.txtOccupation_Validating);
            // 
            // txtEducation
            // 
            this.txtEducation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEducation.Location = new System.Drawing.Point(170, 16);
            this.txtEducation.Name = "txtEducation";
            this.txtEducation.Size = new System.Drawing.Size(238, 22);
            this.txtEducation.TabIndex = 0;
            this.txtEducation.Tag = "comtxtEducation";
            this.txtEducation.Validating += new System.ComponentModel.CancelEventHandler(this.txtEducation_Validating);
            // 
            // ddlAnnualIncomeCurrency
            // 
            this.ddlAnnualIncomeCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlAnnualIncomeCurrency.FormattingEnabled = true;
            this.ddlAnnualIncomeCurrency.Location = new System.Drawing.Point(578, 58);
            this.ddlAnnualIncomeCurrency.Name = "ddlAnnualIncomeCurrency";
            this.ddlAnnualIncomeCurrency.Size = new System.Drawing.Size(65, 22);
            this.ddlAnnualIncomeCurrency.TabIndex = 5;
            this.ddlAnnualIncomeCurrency.Tag = "*AnnualIncomeCurrency";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(17, 61);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(148, 13);
            this.label103.TabIndex = 301;
            this.label103.Text = "Working State / City :";
            // 
            // ddlAnnualIncome
            // 
            this.ddlAnnualIncome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlAnnualIncome.FormattingEnabled = true;
            this.ddlAnnualIncome.Location = new System.Drawing.Point(643, 58);
            this.ddlAnnualIncome.Name = "ddlAnnualIncome";
            this.ddlAnnualIncome.Size = new System.Drawing.Size(173, 22);
            this.ddlAnnualIncome.TabIndex = 6;
            this.ddlAnnualIncome.Tag = "*AnnualIncome";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(443, 63);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(114, 14);
            this.label36.TabIndex = 300;
            this.label36.Text = "Annual Income :";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(1, 41);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(164, 13);
            this.label37.TabIndex = 299;
            this.label37.Text = "Occupation/Profession :";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(85, 20);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(80, 14);
            this.label41.TabIndex = 298;
            this.label41.Text = "Education :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label29.Location = new System.Drawing.Point(17, 131);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(113, 16);
            this.label29.TabIndex = 287;
            this.label29.Text = "Contact Details";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ddlLandlineNo1_Rel);
            this.groupBox4.Controls.Add(this.label99);
            this.groupBox4.Controls.Add(this.txtVisaCountryCode);
            this.groupBox4.Controls.Add(this.txtVisaStatusCode);
            this.groupBox4.Controls.Add(this.txtStateCityCode);
            this.groupBox4.Controls.Add(this.txtCountryCode);
            this.groupBox4.Controls.Add(this.ddlMobileNo1_Rel);
            this.groupBox4.Controls.Add(this.ddlMobileNo_Rel);
            this.groupBox4.Controls.Add(this.txtMobileNo);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.chkChangePassword);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.txtPassword);
            this.groupBox4.Controls.Add(this.txtHomeAddress1);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.txtHomeAddress2);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.txtLandlineNo1);
            this.groupBox4.Controls.Add(this.label95);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.txtCountry);
            this.groupBox4.Controls.Add(this.txtMobileNo1);
            this.groupBox4.Controls.Add(this.txtStateCity);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.txtVisaStatus);
            this.groupBox4.Controls.Add(this.txtEmailID);
            this.groupBox4.Controls.Add(this.label51);
            this.groupBox4.Controls.Add(this.label110);
            this.groupBox4.Controls.Add(this.txtVisaCountry);
            this.groupBox4.Controls.Add(this.txtSecondaryEmailID);
            this.groupBox4.Controls.Add(this.label96);
            this.groupBox4.Controls.Add(this.txtLandlineNo);
            this.groupBox4.Controls.Add(this.ddlMobileNo2_Rel);
            this.groupBox4.Location = new System.Drawing.Point(11, 134);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(860, 190);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // ddlLandlineNo1_Rel
            // 
            this.ddlLandlineNo1_Rel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlLandlineNo1_Rel.FormattingEnabled = true;
            this.ddlLandlineNo1_Rel.Location = new System.Drawing.Point(722, 77);
            this.ddlLandlineNo1_Rel.Name = "ddlLandlineNo1_Rel";
            this.ddlLandlineNo1_Rel.Size = new System.Drawing.Size(95, 22);
            this.ddlLandlineNo1_Rel.TabIndex = 332;
            this.ddlLandlineNo1_Rel.Tag = "LandlineNo1_Rel";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(411, 124);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(146, 14);
            this.label99.TabIndex = 314;
            this.label99.Text = "Secondary Email ID :";
            // 
            // txtVisaCountryCode
            // 
            this.txtVisaCountryCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVisaCountryCode.Location = new System.Drawing.Point(408, 159);
            this.txtVisaCountryCode.Name = "txtVisaCountryCode";
            this.txtVisaCountryCode.Size = new System.Drawing.Size(13, 22);
            this.txtVisaCountryCode.TabIndex = 331;
            this.txtVisaCountryCode.Tag = "*VisaCountry";
            this.txtVisaCountryCode.Visible = false;
            // 
            // txtVisaStatusCode
            // 
            this.txtVisaStatusCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVisaStatusCode.Location = new System.Drawing.Point(408, 138);
            this.txtVisaStatusCode.Name = "txtVisaStatusCode";
            this.txtVisaStatusCode.Size = new System.Drawing.Size(13, 22);
            this.txtVisaStatusCode.TabIndex = 330;
            this.txtVisaStatusCode.Tag = "*VisaStatus";
            this.txtVisaStatusCode.Visible = false;
            // 
            // txtStateCityCode
            // 
            this.txtStateCityCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStateCityCode.Location = new System.Drawing.Point(408, 117);
            this.txtStateCityCode.Name = "txtStateCityCode";
            this.txtStateCityCode.Size = new System.Drawing.Size(13, 22);
            this.txtStateCityCode.TabIndex = 329;
            this.txtStateCityCode.Tag = "*StateCity";
            this.txtStateCityCode.Visible = false;
            // 
            // txtCountryCode
            // 
            this.txtCountryCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCountryCode.Location = new System.Drawing.Point(408, 96);
            this.txtCountryCode.Name = "txtCountryCode";
            this.txtCountryCode.Size = new System.Drawing.Size(13, 22);
            this.txtCountryCode.TabIndex = 328;
            this.txtCountryCode.Tag = "*Country";
            this.txtCountryCode.Visible = false;
            // 
            // ddlMobileNo1_Rel
            // 
            this.ddlMobileNo1_Rel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlMobileNo1_Rel.FormattingEnabled = true;
            this.ddlMobileNo1_Rel.Location = new System.Drawing.Point(722, 36);
            this.ddlMobileNo1_Rel.Name = "ddlMobileNo1_Rel";
            this.ddlMobileNo1_Rel.Size = new System.Drawing.Size(95, 22);
            this.ddlMobileNo1_Rel.TabIndex = 9;
            this.ddlMobileNo1_Rel.Tag = "MobileNo1_Rel";
            // 
            // ddlMobileNo_Rel
            // 
            this.ddlMobileNo_Rel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlMobileNo_Rel.FormattingEnabled = true;
            this.ddlMobileNo_Rel.Location = new System.Drawing.Point(722, 15);
            this.ddlMobileNo_Rel.Name = "ddlMobileNo_Rel";
            this.ddlMobileNo_Rel.Size = new System.Drawing.Size(95, 22);
            this.ddlMobileNo_Rel.TabIndex = 7;
            this.ddlMobileNo_Rel.Tag = "MobileNo_Rel";
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMobileNo.Location = new System.Drawing.Point(578, 15);
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.Size = new System.Drawing.Size(144, 22);
            this.txtMobileNo.TabIndex = 6;
            this.txtMobileNo.Tag = "MobileNo";
            this.txtMobileNo.Validating += new System.ComponentModel.CancelEventHandler(this.txtMobileNo_Validating);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(83, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(82, 14);
            this.label24.TabIndex = 299;
            this.label24.Text = "Address 1 :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(83, 61);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(82, 14);
            this.label25.TabIndex = 300;
            this.label25.Text = "Address 2 :";
            // 
            // chkChangePassword
            // 
            this.chkChangePassword.AutoSize = true;
            this.chkChangePassword.Location = new System.Drawing.Point(578, 164);
            this.chkChangePassword.Name = "chkChangePassword";
            this.chkChangePassword.Size = new System.Drawing.Size(144, 18);
            this.chkChangePassword.TabIndex = 16;
            this.chkChangePassword.TabStop = false;
            this.chkChangePassword.Text = "Change Password";
            this.chkChangePassword.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(75, 141);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(90, 14);
            this.label26.TabIndex = 301;
            this.label26.Text = "Visa Status :";
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.White;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPassword.Location = new System.Drawing.Point(578, 141);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.ReadOnly = true;
            this.txtPassword.Size = new System.Drawing.Size(239, 22);
            this.txtPassword.TabIndex = 15;
            this.txtPassword.Tag = "Password";
            // 
            // txtHomeAddress1
            // 
            this.txtHomeAddress1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHomeAddress1.Location = new System.Drawing.Point(167, 15);
            this.txtHomeAddress1.Multiline = true;
            this.txtHomeAddress1.Name = "txtHomeAddress1";
            this.txtHomeAddress1.Size = new System.Drawing.Size(240, 43);
            this.txtHomeAddress1.TabIndex = 0;
            this.txtHomeAddress1.Tag = "HomeAddress1";
            this.txtHomeAddress1.Validating += new System.ComponentModel.CancelEventHandler(this.txtHomeAddress1_Validating);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(476, 145);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(81, 14);
            this.label35.TabIndex = 319;
            this.label35.Text = "Password :";
            // 
            // txtHomeAddress2
            // 
            this.txtHomeAddress2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHomeAddress2.Location = new System.Drawing.Point(167, 57);
            this.txtHomeAddress2.Multiline = true;
            this.txtHomeAddress2.Name = "txtHomeAddress2";
            this.txtHomeAddress2.Size = new System.Drawing.Size(240, 40);
            this.txtHomeAddress2.TabIndex = 1;
            this.txtHomeAddress2.Tag = "HomeAddress2";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(463, 82);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(94, 14);
            this.label33.TabIndex = 318;
            this.label33.Text = "Landline No :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(97, 99);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(68, 14);
            this.label27.TabIndex = 302;
            this.label27.Text = "Country :";
            // 
            // txtLandlineNo1
            // 
            this.txtLandlineNo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLandlineNo1.Location = new System.Drawing.Point(578, 78);
            this.txtLandlineNo1.Name = "txtLandlineNo1";
            this.txtLandlineNo1.Size = new System.Drawing.Size(144, 22);
            this.txtLandlineNo1.TabIndex = 12;
            this.txtLandlineNo1.Tag = "LandlineNo";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(72, 120);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(93, 14);
            this.label95.TabIndex = 303;
            this.label95.Text = "State / City :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(463, 39);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(94, 14);
            this.label30.TabIndex = 317;
            this.label30.Text = "Mobile No 2 :";
            // 
            // txtCountry
            // 
            this.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCountry.Location = new System.Drawing.Point(167, 96);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(240, 22);
            this.txtCountry.TabIndex = 2;
            this.txtCountry.Tag = "comtxtCountry";
            this.txtCountry.Validated += new System.EventHandler(this.txtCountry_Validated);
            // 
            // txtMobileNo1
            // 
            this.txtMobileNo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMobileNo1.Location = new System.Drawing.Point(578, 36);
            this.txtMobileNo1.Name = "txtMobileNo1";
            this.txtMobileNo1.Size = new System.Drawing.Size(144, 22);
            this.txtMobileNo1.TabIndex = 8;
            this.txtMobileNo1.Tag = "MobileNo1";
            // 
            // txtStateCity
            // 
            this.txtStateCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStateCity.Location = new System.Drawing.Point(167, 117);
            this.txtStateCity.Name = "txtStateCity";
            this.txtStateCity.Size = new System.Drawing.Size(240, 22);
            this.txtStateCity.TabIndex = 3;
            this.txtStateCity.Tag = "comtxtState / City";
            this.txtStateCity.Validated += new System.EventHandler(this.txtStateCity_Validated);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(463, 61);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 14);
            this.label16.TabIndex = 316;
            this.label16.Text = "Mobile No 3 :";
            // 
            // txtVisaStatus
            // 
            this.txtVisaStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVisaStatus.Location = new System.Drawing.Point(167, 138);
            this.txtVisaStatus.Name = "txtVisaStatus";
            this.txtVisaStatus.Size = new System.Drawing.Size(240, 22);
            this.txtVisaStatus.TabIndex = 4;
            this.txtVisaStatus.Tag = "nontxtVisa Status";
            this.txtVisaStatus.Validated += new System.EventHandler(this.txtVisaStatus_Validated);
            // 
            // txtEmailID
            // 
            this.txtEmailID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmailID.Location = new System.Drawing.Point(578, 99);
            this.txtEmailID.Name = "txtEmailID";
            this.txtEmailID.Size = new System.Drawing.Size(239, 22);
            this.txtEmailID.TabIndex = 13;
            this.txtEmailID.Tag = "EmailID";
            this.txtEmailID.Validating += new System.ComponentModel.CancelEventHandler(this.txtEmailID_Validating);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(65, 162);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(100, 14);
            this.label51.TabIndex = 304;
            this.label51.Text = "Visa Country :";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(428, 103);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(129, 14);
            this.label110.TabIndex = 315;
            this.label110.Text = "Primary Email ID :";
            // 
            // txtVisaCountry
            // 
            this.txtVisaCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVisaCountry.Location = new System.Drawing.Point(167, 159);
            this.txtVisaCountry.Name = "txtVisaCountry";
            this.txtVisaCountry.Size = new System.Drawing.Size(240, 22);
            this.txtVisaCountry.TabIndex = 5;
            this.txtVisaCountry.Tag = "nontxtVisa Status";
            this.txtVisaCountry.Validated += new System.EventHandler(this.txtVisaCountry_Validated);
            // 
            // txtSecondaryEmailID
            // 
            this.txtSecondaryEmailID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSecondaryEmailID.Location = new System.Drawing.Point(578, 120);
            this.txtSecondaryEmailID.Name = "txtSecondaryEmailID";
            this.txtSecondaryEmailID.Size = new System.Drawing.Size(239, 22);
            this.txtSecondaryEmailID.TabIndex = 14;
            this.txtSecondaryEmailID.Tag = "SecondaryEmailID";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(463, 19);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(94, 14);
            this.label96.TabIndex = 313;
            this.label96.Text = "Mobile No 1 :";
            // 
            // txtLandlineNo
            // 
            this.txtLandlineNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLandlineNo.Location = new System.Drawing.Point(578, 57);
            this.txtLandlineNo.Name = "txtLandlineNo";
            this.txtLandlineNo.Size = new System.Drawing.Size(144, 22);
            this.txtLandlineNo.TabIndex = 10;
            this.txtLandlineNo.Tag = "LandlineNo1";
            // 
            // ddlMobileNo2_Rel
            // 
            this.ddlMobileNo2_Rel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlMobileNo2_Rel.FormattingEnabled = true;
            this.ddlMobileNo2_Rel.Location = new System.Drawing.Point(722, 57);
            this.ddlMobileNo2_Rel.Name = "ddlMobileNo2_Rel";
            this.ddlMobileNo2_Rel.Size = new System.Drawing.Size(95, 22);
            this.ddlMobileNo2_Rel.TabIndex = 11;
            this.ddlMobileNo2_Rel.Tag = "MobileNo2_Rel";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmbBirthPlace);
            this.groupBox3.Controls.Add(this.ddlMaritalStatus);
            this.groupBox3.Controls.Add(this.txtBloodGroupCode);
            this.groupBox3.Controls.Add(this.txtSubCasteCode);
            this.groupBox3.Controls.Add(this.txtCasteCode);
            this.groupBox3.Controls.Add(this.dtpTime);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.ddlNoOfChildren);
            this.groupBox3.Controls.Add(this.ddlLiveChildrenTogether);
            this.groupBox3.Controls.Add(this.label90);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.txtCaste);
            this.groupBox3.Controls.Add(this.txtSubCaste);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txtWeight);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.ddlHeight);
            this.groupBox3.Controls.Add(this.pnlManglik);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.txtBloodGroup);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox3.Location = new System.Drawing.Point(11, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(860, 131);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // cmbBirthPlace
            // 
            this.cmbBirthPlace.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbBirthPlace.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBirthPlace.FormattingEnabled = true;
            this.cmbBirthPlace.Location = new System.Drawing.Point(579, 36);
            this.cmbBirthPlace.MaxDropDownItems = 10;
            this.cmbBirthPlace.Name = "cmbBirthPlace";
            this.cmbBirthPlace.Size = new System.Drawing.Size(238, 22);
            this.cmbBirthPlace.TabIndex = 3;
            this.cmbBirthPlace.Tag = "";
            // 
            // ddlMaritalStatus
            // 
            this.ddlMaritalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlMaritalStatus.FormattingEnabled = true;
            this.ddlMaritalStatus.Location = new System.Drawing.Point(579, 79);
            this.ddlMaritalStatus.Name = "ddlMaritalStatus";
            this.ddlMaritalStatus.Size = new System.Drawing.Size(238, 22);
            this.ddlMaritalStatus.TabIndex = 7;
            this.ddlMaritalStatus.Tag = "MaritalStatus";
            // 
            // txtBloodGroupCode
            // 
            this.txtBloodGroupCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBloodGroupCode.Location = new System.Drawing.Point(410, 99);
            this.txtBloodGroupCode.Name = "txtBloodGroupCode";
            this.txtBloodGroupCode.Size = new System.Drawing.Size(13, 22);
            this.txtBloodGroupCode.TabIndex = 326;
            this.txtBloodGroupCode.Tag = "*BloodGroup";
            this.txtBloodGroupCode.Visible = false;
            // 
            // txtSubCasteCode
            // 
            this.txtSubCasteCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSubCasteCode.Location = new System.Drawing.Point(408, 35);
            this.txtSubCasteCode.Name = "txtSubCasteCode";
            this.txtSubCasteCode.Size = new System.Drawing.Size(13, 22);
            this.txtSubCasteCode.TabIndex = 325;
            this.txtSubCasteCode.Tag = "SubCaste";
            this.txtSubCasteCode.Visible = false;
            // 
            // txtCasteCode
            // 
            this.txtCasteCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCasteCode.Location = new System.Drawing.Point(408, 14);
            this.txtCasteCode.Name = "txtCasteCode";
            this.txtCasteCode.Size = new System.Drawing.Size(13, 22);
            this.txtCasteCode.TabIndex = 324;
            this.txtCasteCode.Tag = "Caste";
            this.txtCasteCode.Visible = false;
            // 
            // dtpTime
            // 
            this.dtpTime.CustomFormat = "HH:mm";
            this.dtpTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTime.Location = new System.Drawing.Point(579, 14);
            this.dtpTime.Name = "dtpTime";
            this.dtpTime.ShowUpDown = true;
            this.dtpTime.Size = new System.Drawing.Size(122, 22);
            this.dtpTime.TabIndex = 1;
            this.dtpTime.Tag = "TimeofBirth";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(469, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 14);
            this.label3.TabIndex = 269;
            this.label3.Text = "Birth Place :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(453, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 14);
            this.label4.TabIndex = 271;
            this.label4.Text = "MaritalStatus :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(444, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 14);
            this.label5.TabIndex = 274;
            this.label5.Text = "No Of Children :";
            // 
            // ddlNoOfChildren
            // 
            this.ddlNoOfChildren.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlNoOfChildren.FormattingEnabled = true;
            this.ddlNoOfChildren.Items.AddRange(new object[] {
            "No",
            "1",
            "2",
            ">2"});
            this.ddlNoOfChildren.Location = new System.Drawing.Point(579, 101);
            this.ddlNoOfChildren.Name = "ddlNoOfChildren";
            this.ddlNoOfChildren.Size = new System.Drawing.Size(93, 22);
            this.ddlNoOfChildren.TabIndex = 9;
            this.ddlNoOfChildren.Tag = "NoOfChildren";
            // 
            // ddlLiveChildrenTogether
            // 
            this.ddlLiveChildrenTogether.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlLiveChildrenTogether.FormattingEnabled = true;
            this.ddlLiveChildrenTogether.Items.AddRange(new object[] {
            "-",
            "Living together",
            "Not Living Together"});
            this.ddlLiveChildrenTogether.Location = new System.Drawing.Point(678, 101);
            this.ddlLiveChildrenTogether.Name = "ddlLiveChildrenTogether";
            this.ddlLiveChildrenTogether.Size = new System.Drawing.Size(139, 22);
            this.ddlLiveChildrenTogether.TabIndex = 10;
            this.ddlLiveChildrenTogether.Tag = "LiveChildrenTogether";
            this.ddlLiveChildrenTogether.SelectedIndexChanged += new System.EventHandler(this.ddlLiveChildrenTogether_SelectedIndexChanged);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(490, 59);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(67, 14);
            this.label90.TabIndex = 279;
            this.label90.Text = "Manglik :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(112, 18);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(53, 14);
            this.label31.TabIndex = 277;
            this.label31.Text = "Caste :";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(81, 39);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(84, 14);
            this.label32.TabIndex = 278;
            this.label32.Text = "Sub-Caste :";
            // 
            // txtCaste
            // 
            this.txtCaste.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCaste.Location = new System.Drawing.Point(168, 14);
            this.txtCaste.Name = "txtCaste";
            this.txtCaste.Size = new System.Drawing.Size(239, 22);
            this.txtCaste.TabIndex = 0;
            this.txtCaste.Tag = "comtxtCaste";
            this.txtCaste.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCaste_KeyDown);
            this.txtCaste.Validating += new System.ComponentModel.CancelEventHandler(this.txtCaste_Validating);
            // 
            // txtSubCaste
            // 
            this.txtSubCaste.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSubCaste.Location = new System.Drawing.Point(168, 35);
            this.txtSubCaste.Name = "txtSubCaste";
            this.txtSubCaste.Size = new System.Drawing.Size(239, 22);
            this.txtSubCaste.TabIndex = 2;
            this.txtSubCaste.Tag = "nontxtSub-Caste";
            this.txtSubCaste.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSubCaste_KeyDown);
            this.txtSubCaste.Validating += new System.ComponentModel.CancelEventHandler(this.txtSubCaste_Validating);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(456, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(101, 14);
            this.label19.TabIndex = 280;
            this.label19.Text = "Time of Birth :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(106, 60);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 14);
            this.label14.TabIndex = 281;
            this.label14.Text = "Height :";
            // 
            // txtWeight
            // 
            this.txtWeight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtWeight.Location = new System.Drawing.Point(168, 77);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(81, 22);
            this.txtWeight.TabIndex = 6;
            this.txtWeight.Tag = "*Weight";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(102, 79);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 14);
            this.label15.TabIndex = 282;
            this.label15.Text = "Weight :";
            // 
            // ddlHeight
            // 
            this.ddlHeight.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlHeight.FormattingEnabled = true;
            this.ddlHeight.Location = new System.Drawing.Point(168, 56);
            this.ddlHeight.Name = "ddlHeight";
            this.ddlHeight.Size = new System.Drawing.Size(239, 22);
            this.ddlHeight.TabIndex = 4;
            this.ddlHeight.Tag = "Height";
            // 
            // pnlManglik
            // 
            this.pnlManglik.Controls.Add(this.rdbtnManglikDontKnow);
            this.pnlManglik.Controls.Add(this.rdbtnManglikNo);
            this.pnlManglik.Controls.Add(this.rdbtnManglikYes);
            this.pnlManglik.Location = new System.Drawing.Point(579, 58);
            this.pnlManglik.Name = "pnlManglik";
            this.pnlManglik.Size = new System.Drawing.Size(240, 22);
            this.pnlManglik.TabIndex = 5;
            // 
            // rdbtnManglikDontKnow
            // 
            this.rdbtnManglikDontKnow.AutoSize = true;
            this.rdbtnManglikDontKnow.Location = new System.Drawing.Point(119, 3);
            this.rdbtnManglikDontKnow.Name = "rdbtnManglikDontKnow";
            this.rdbtnManglikDontKnow.Size = new System.Drawing.Size(116, 18);
            this.rdbtnManglikDontKnow.TabIndex = 2;
            this.rdbtnManglikDontKnow.TabStop = true;
            this.rdbtnManglikDontKnow.Text = "Doesn\'t Know";
            this.rdbtnManglikDontKnow.UseVisualStyleBackColor = true;
            // 
            // rdbtnManglikNo
            // 
            this.rdbtnManglikNo.AutoSize = true;
            this.rdbtnManglikNo.Location = new System.Drawing.Point(59, 3);
            this.rdbtnManglikNo.Name = "rdbtnManglikNo";
            this.rdbtnManglikNo.Size = new System.Drawing.Size(43, 18);
            this.rdbtnManglikNo.TabIndex = 1;
            this.rdbtnManglikNo.TabStop = true;
            this.rdbtnManglikNo.Text = "No";
            this.rdbtnManglikNo.UseVisualStyleBackColor = true;
            // 
            // rdbtnManglikYes
            // 
            this.rdbtnManglikYes.AutoSize = true;
            this.rdbtnManglikYes.Location = new System.Drawing.Point(5, 3);
            this.rdbtnManglikYes.Name = "rdbtnManglikYes";
            this.rdbtnManglikYes.Size = new System.Drawing.Size(50, 18);
            this.rdbtnManglikYes.TabIndex = 0;
            this.rdbtnManglikYes.TabStop = true;
            this.rdbtnManglikYes.Text = "Yes";
            this.rdbtnManglikYes.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(68, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(97, 14);
            this.label23.TabIndex = 285;
            this.label23.Text = "Blood Group :";
            // 
            // txtBloodGroup
            // 
            this.txtBloodGroup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBloodGroup.Location = new System.Drawing.Point(168, 98);
            this.txtBloodGroup.Name = "txtBloodGroup";
            this.txtBloodGroup.Size = new System.Drawing.Size(240, 22);
            this.txtBloodGroup.TabIndex = 8;
            this.txtBloodGroup.Tag = "%BloodGroup";
            this.txtBloodGroup.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBloodGroup_KeyDown);
            this.txtBloodGroup.Validating += new System.ComponentModel.CancelEventHandler(this.txtBloodGroup_Validating);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnSave_FamilyDtl);
            this.tabPage2.Controls.Add(this.txtFileNote);
            this.tabPage2.Controls.Add(this.label38);
            this.tabPage2.Controls.Add(this.label43);
            this.tabPage2.Controls.Add(this.groupBox11);
            this.tabPage2.Controls.Add(this.label42);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(889, 458);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "About Family & Self";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnSave_FamilyDtl
            // 
            this.btnSave_FamilyDtl.Location = new System.Drawing.Point(776, 421);
            this.btnSave_FamilyDtl.Name = "btnSave_FamilyDtl";
            this.btnSave_FamilyDtl.Size = new System.Drawing.Size(94, 31);
            this.btnSave_FamilyDtl.TabIndex = 323;
            this.btnSave_FamilyDtl.Text = "Save";
            this.btnSave_FamilyDtl.UseVisualStyleBackColor = true;
            // 
            // txtFileNote
            // 
            this.txtFileNote.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFileNote.Location = new System.Drawing.Point(94, 375);
            this.txtFileNote.MaxLength = 50;
            this.txtFileNote.Name = "txtFileNote";
            this.txtFileNote.Size = new System.Drawing.Size(248, 22);
            this.txtFileNote.TabIndex = 0;
            this.txtFileNote.Tag = "FileNote";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(17, 378);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(75, 14);
            this.label38.TabIndex = 280;
            this.label38.Text = "File Note :";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label43.Location = new System.Drawing.Point(482, 297);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(65, 14);
            this.label43.TabIndex = 279;
            this.label43.Text = "Remarks";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.txtRemarks);
            this.groupBox11.Location = new System.Drawing.Point(469, 296);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(410, 69);
            this.groupBox11.TabIndex = 278;
            this.groupBox11.TabStop = false;
            // 
            // txtRemarks
            // 
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRemarks.Location = new System.Drawing.Point(13, 20);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(388, 40);
            this.txtRemarks.TabIndex = 0;
            this.txtRemarks.Tag = "Remarks";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label42.Location = new System.Drawing.Point(24, 297);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(51, 14);
            this.label42.TabIndex = 277;
            this.label42.Text = "Choice";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtChoice);
            this.groupBox8.Location = new System.Drawing.Point(12, 296);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(431, 69);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            // 
            // txtChoice
            // 
            this.txtChoice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtChoice.Location = new System.Drawing.Point(15, 20);
            this.txtChoice.Multiline = true;
            this.txtChoice.Name = "txtChoice";
            this.txtChoice.Size = new System.Drawing.Size(410, 40);
            this.txtChoice.TabIndex = 0;
            this.txtChoice.Tag = "Choice";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label18.Location = new System.Drawing.Point(24, 213);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 14);
            this.label18.TabIndex = 273;
            this.label18.Text = "About My Self";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtAboutInfo);
            this.groupBox1.Location = new System.Drawing.Point(12, 214);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(867, 81);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // txtAboutInfo
            // 
            this.txtAboutInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAboutInfo.Location = new System.Drawing.Point(15, 20);
            this.txtAboutInfo.Multiline = true;
            this.txtAboutInfo.Name = "txtAboutInfo";
            this.txtAboutInfo.Size = new System.Drawing.Size(844, 53);
            this.txtAboutInfo.TabIndex = 0;
            this.txtAboutInfo.Tag = "AboutInfo";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label22.Location = new System.Drawing.Point(24, 95);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(126, 14);
            this.label22.TabIndex = 271;
            this.label22.Text = "Brothers / Sisters";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel2);
            this.groupBox2.Location = new System.Drawing.Point(13, 96);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(868, 115);
            this.groupBox2.TabIndex = 270;
            this.groupBox2.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dgvSiblingDetails);
            this.panel2.Location = new System.Drawing.Point(6, 21);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(856, 85);
            this.panel2.TabIndex = 0;
            // 
            // dgvSiblingDetails
            // 
            this.dgvSiblingDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSiblingDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSiblingDetails.Location = new System.Drawing.Point(0, 0);
            this.dgvSiblingDetails.Name = "dgvSiblingDetails";
            this.dgvSiblingDetails.Size = new System.Drawing.Size(856, 85);
            this.dgvSiblingDetails.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label6.Location = new System.Drawing.Point(24, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 14);
            this.label6.TabIndex = 111;
            this.label6.Text = "Family Details";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtMotherOccupation);
            this.groupBox9.Controls.Add(this.txtFatherOccupation);
            this.groupBox9.Controls.Add(this.txtNativePlace);
            this.groupBox9.Controls.Add(this.label56);
            this.groupBox9.Controls.Add(this.txtMosalPlace);
            this.groupBox9.Controls.Add(this.label50);
            this.groupBox9.Controls.Add(this.label49);
            this.groupBox9.Controls.Add(this.label48);
            this.groupBox9.Controls.Add(this.txtMotherName);
            this.groupBox9.Controls.Add(this.label47);
            this.groupBox9.Controls.Add(this.txtFatherName);
            this.groupBox9.Controls.Add(this.label46);
            this.groupBox9.Location = new System.Drawing.Point(11, 4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(870, 90);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            // 
            // txtMotherOccupation
            // 
            this.txtMotherOccupation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMotherOccupation.Location = new System.Drawing.Point(589, 38);
            this.txtMotherOccupation.Name = "txtMotherOccupation";
            this.txtMotherOccupation.Size = new System.Drawing.Size(239, 22);
            this.txtMotherOccupation.TabIndex = 4;
            this.txtMotherOccupation.Tag = "MotherOccupation";
            // 
            // txtFatherOccupation
            // 
            this.txtFatherOccupation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFatherOccupation.Location = new System.Drawing.Point(589, 17);
            this.txtFatherOccupation.Name = "txtFatherOccupation";
            this.txtFatherOccupation.Size = new System.Drawing.Size(239, 22);
            this.txtFatherOccupation.TabIndex = 3;
            this.txtFatherOccupation.Tag = "FatherOccupation";
            // 
            // txtNativePlace
            // 
            this.txtNativePlace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNativePlace.Location = new System.Drawing.Point(589, 59);
            this.txtNativePlace.Name = "txtNativePlace";
            this.txtNativePlace.Size = new System.Drawing.Size(239, 22);
            this.txtNativePlace.TabIndex = 5;
            this.txtNativePlace.Tag = "NativePlace";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(486, 62);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(99, 14);
            this.label56.TabIndex = 93;
            this.label56.Text = "Native Place :";
            // 
            // txtMosalPlace
            // 
            this.txtMosalPlace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMosalPlace.Location = new System.Drawing.Point(149, 59);
            this.txtMosalPlace.Name = "txtMosalPlace";
            this.txtMosalPlace.Size = new System.Drawing.Size(248, 22);
            this.txtMosalPlace.TabIndex = 2;
            this.txtMosalPlace.Tag = "MosalPlace";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(52, 63);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(94, 14);
            this.label50.TabIndex = 92;
            this.label50.Text = "Mosal Place :";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(434, 41);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(151, 14);
            this.label49.TabIndex = 91;
            this.label49.Text = "Mother\'s Occupation :";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(437, 19);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(148, 14);
            this.label48.TabIndex = 90;
            this.label48.Text = "Father\'s Occupation :";
            // 
            // txtMotherName
            // 
            this.txtMotherName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMotherName.Location = new System.Drawing.Point(149, 38);
            this.txtMotherName.Name = "txtMotherName";
            this.txtMotherName.Size = new System.Drawing.Size(248, 22);
            this.txtMotherName.TabIndex = 1;
            this.txtMotherName.Tag = "MotherName";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(31, 41);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(115, 14);
            this.label47.TabIndex = 89;
            this.label47.Text = "Mother\'s Name :";
            // 
            // txtFatherName
            // 
            this.txtFatherName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFatherName.Location = new System.Drawing.Point(149, 17);
            this.txtFatherName.Name = "txtFatherName";
            this.txtFatherName.Size = new System.Drawing.Size(248, 22);
            this.txtFatherName.TabIndex = 0;
            this.txtFatherName.Tag = "FatherName";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(45, 20);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(101, 14);
            this.label46.TabIndex = 88;
            this.label46.Text = "Father Name :";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnSave_PartnerPref);
            this.tabPage3.Controls.Add(this.label34);
            this.tabPage3.Controls.Add(this.label89);
            this.tabPage3.Controls.Add(this.label88);
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(889, 458);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = " Partner Preference";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnSave_PartnerPref
            // 
            this.btnSave_PartnerPref.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave_PartnerPref.Location = new System.Drawing.Point(777, 412);
            this.btnSave_PartnerPref.Name = "btnSave_PartnerPref";
            this.btnSave_PartnerPref.Size = new System.Drawing.Size(94, 31);
            this.btnSave_PartnerPref.TabIndex = 324;
            this.btnSave_PartnerPref.Text = "Save";
            this.btnSave_PartnerPref.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label34.Location = new System.Drawing.Point(35, 385);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(128, 14);
            this.label34.TabIndex = 269;
            this.label34.Text = "About Life Partner";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label89.Location = new System.Drawing.Point(35, 307);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(114, 14);
            this.label89.TabIndex = 263;
            this.label89.Text = "Partner Religion";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.label88.Location = new System.Drawing.Point(35, 3);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(105, 14);
            this.label88.TabIndex = 261;
            this.label88.Text = "Partner Choice";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.ddlPHeightTo);
            this.groupBox10.Controls.Add(this.ddlPAgeTo);
            this.groupBox10.Controls.Add(this.ddlPHeightFrom);
            this.groupBox10.Controls.Add(this.ddlPAgeFrom);
            this.groupBox10.Controls.Add(this.chkPWorkingWith);
            this.groupBox10.Controls.Add(this.chkPOccupation);
            this.groupBox10.Controls.Add(this.chkPEducation);
            this.groupBox10.Controls.Add(this.chkPVisaStatus);
            this.groupBox10.Controls.Add(this.chkPCountryLivingIn);
            this.groupBox10.Controls.Add(this.chkPMaritalStatus);
            this.groupBox10.Controls.Add(this.label108);
            this.groupBox10.Controls.Add(this.ddlPAnnualIncomeCurrency);
            this.groupBox10.Controls.Add(this.ddlPAnnualIncome);
            this.groupBox10.Controls.Add(this.label107);
            this.groupBox10.Controls.Add(this.label105);
            this.groupBox10.Controls.Add(this.label106);
            this.groupBox10.Controls.Add(this.label87);
            this.groupBox10.Controls.Add(this.label86);
            this.groupBox10.Controls.Add(this.label7);
            this.groupBox10.Controls.Add(this.label8);
            this.groupBox10.Controls.Add(this.label9);
            this.groupBox10.Controls.Add(this.label10);
            this.groupBox10.Controls.Add(this.cmbPHaveChildrens);
            this.groupBox10.Controls.Add(this.label11);
            this.groupBox10.Controls.Add(this.label12);
            this.groupBox10.Location = new System.Drawing.Point(14, 2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(857, 304);
            this.groupBox10.TabIndex = 262;
            this.groupBox10.TabStop = false;
            // 
            // ddlPHeightTo
            // 
            this.ddlPHeightTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPHeightTo.FormattingEnabled = true;
            this.ddlPHeightTo.Location = new System.Drawing.Point(292, 39);
            this.ddlPHeightTo.Name = "ddlPHeightTo";
            this.ddlPHeightTo.Size = new System.Drawing.Size(116, 22);
            this.ddlPHeightTo.TabIndex = 3;
            this.ddlPHeightTo.Tag = "nonHeight upto";
            // 
            // ddlPAgeTo
            // 
            this.ddlPAgeTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPAgeTo.FormattingEnabled = true;
            this.ddlPAgeTo.Location = new System.Drawing.Point(292, 17);
            this.ddlPAgeTo.Name = "ddlPAgeTo";
            this.ddlPAgeTo.Size = new System.Drawing.Size(116, 22);
            this.ddlPAgeTo.TabIndex = 1;
            this.ddlPAgeTo.Tag = "nonBorn Year upto";
            // 
            // ddlPHeightFrom
            // 
            this.ddlPHeightFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPHeightFrom.FormattingEnabled = true;
            this.ddlPHeightFrom.Location = new System.Drawing.Point(149, 39);
            this.ddlPHeightFrom.Name = "ddlPHeightFrom";
            this.ddlPHeightFrom.Size = new System.Drawing.Size(116, 22);
            this.ddlPHeightFrom.TabIndex = 2;
            this.ddlPHeightFrom.Tag = "nonHeight from";
            // 
            // ddlPAgeFrom
            // 
            this.ddlPAgeFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPAgeFrom.FormattingEnabled = true;
            this.ddlPAgeFrom.Location = new System.Drawing.Point(149, 17);
            this.ddlPAgeFrom.Name = "ddlPAgeFrom";
            this.ddlPAgeFrom.Size = new System.Drawing.Size(116, 22);
            this.ddlPAgeFrom.TabIndex = 0;
            this.ddlPAgeFrom.Tag = "nonBorn Year Start";
            // 
            // chkPWorkingWith
            // 
            this.chkPWorkingWith.CheckOnClick = true;
            this.chkPWorkingWith.FormattingEnabled = true;
            this.chkPWorkingWith.Location = new System.Drawing.Point(587, 182);
            this.chkPWorkingWith.Name = "chkPWorkingWith";
            this.chkPWorkingWith.Size = new System.Drawing.Size(260, 72);
            this.chkPWorkingWith.TabIndex = 10;
            // 
            // chkPOccupation
            // 
            this.chkPOccupation.CheckOnClick = true;
            this.chkPOccupation.FormattingEnabled = true;
            this.chkPOccupation.Location = new System.Drawing.Point(587, 97);
            this.chkPOccupation.Name = "chkPOccupation";
            this.chkPOccupation.Size = new System.Drawing.Size(260, 72);
            this.chkPOccupation.TabIndex = 9;
            // 
            // chkPEducation
            // 
            this.chkPEducation.CheckOnClick = true;
            this.chkPEducation.FormattingEnabled = true;
            this.chkPEducation.Location = new System.Drawing.Point(587, 20);
            this.chkPEducation.Name = "chkPEducation";
            this.chkPEducation.Size = new System.Drawing.Size(260, 72);
            this.chkPEducation.TabIndex = 8;
            // 
            // chkPVisaStatus
            // 
            this.chkPVisaStatus.CheckOnClick = true;
            this.chkPVisaStatus.FormattingEnabled = true;
            this.chkPVisaStatus.Location = new System.Drawing.Point(149, 227);
            this.chkPVisaStatus.Name = "chkPVisaStatus";
            this.chkPVisaStatus.Size = new System.Drawing.Size(260, 72);
            this.chkPVisaStatus.TabIndex = 7;
            // 
            // chkPCountryLivingIn
            // 
            this.chkPCountryLivingIn.CheckOnClick = true;
            this.chkPCountryLivingIn.FormattingEnabled = true;
            this.chkPCountryLivingIn.Location = new System.Drawing.Point(149, 155);
            this.chkPCountryLivingIn.Name = "chkPCountryLivingIn";
            this.chkPCountryLivingIn.Size = new System.Drawing.Size(260, 72);
            this.chkPCountryLivingIn.TabIndex = 6;
            // 
            // chkPMaritalStatus
            // 
            this.chkPMaritalStatus.CheckOnClick = true;
            this.chkPMaritalStatus.FormattingEnabled = true;
            this.chkPMaritalStatus.Location = new System.Drawing.Point(149, 61);
            this.chkPMaritalStatus.Name = "chkPMaritalStatus";
            this.chkPMaritalStatus.Size = new System.Drawing.Size(260, 72);
            this.chkPMaritalStatus.TabIndex = 4;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(478, 182);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(107, 14);
            this.label108.TabIndex = 229;
            this.label108.Text = "Working With :";
            // 
            // ddlPAnnualIncomeCurrency
            // 
            this.ddlPAnnualIncomeCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPAnnualIncomeCurrency.FormattingEnabled = true;
            this.ddlPAnnualIncomeCurrency.Location = new System.Drawing.Point(587, 267);
            this.ddlPAnnualIncomeCurrency.Name = "ddlPAnnualIncomeCurrency";
            this.ddlPAnnualIncomeCurrency.Size = new System.Drawing.Size(59, 22);
            this.ddlPAnnualIncomeCurrency.TabIndex = 11;
            this.ddlPAnnualIncomeCurrency.Tag = "nonAnnual Income Currency";
            // 
            // ddlPAnnualIncome
            // 
            this.ddlPAnnualIncome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPAnnualIncome.FormattingEnabled = true;
            this.ddlPAnnualIncome.Location = new System.Drawing.Point(653, 267);
            this.ddlPAnnualIncome.Name = "ddlPAnnualIncome";
            this.ddlPAnnualIncome.Size = new System.Drawing.Size(194, 22);
            this.ddlPAnnualIncome.TabIndex = 12;
            this.ddlPAnnualIncome.Tag = "nonAnnual Income";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(479, 270);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(106, 14);
            this.label107.TabIndex = 228;
            this.label107.Text = "Anual Income :";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(269, 20);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(23, 13);
            this.label105.TabIndex = 227;
            this.label105.Text = "To";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(61, 20);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(83, 14);
            this.label106.TabIndex = 226;
            this.label106.Text = "Born Year :";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(269, 42);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(23, 13);
            this.label87.TabIndex = 225;
            this.label87.Text = "To";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(85, 42);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(59, 14);
            this.label86.TabIndex = 224;
            this.label86.Text = "Height :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(417, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 14);
            this.label7.TabIndex = 223;
            this.label7.Text = "Occupation/Profession :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(505, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 14);
            this.label8.TabIndex = 222;
            this.label8.Text = "Education :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(16, 155);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 14);
            this.label9.TabIndex = 221;
            this.label9.Text = "Country Living in :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(54, 229);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 14);
            this.label10.TabIndex = 220;
            this.label10.Text = "Visa Status :";
            // 
            // cmbPHaveChildrens
            // 
            this.cmbPHaveChildrens.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPHaveChildrens.FormattingEnabled = true;
            this.cmbPHaveChildrens.Items.AddRange(new object[] {
            "No",
            "Ok, If living together.",
            "Ok, but not living together."});
            this.cmbPHaveChildrens.Location = new System.Drawing.Point(149, 133);
            this.cmbPHaveChildrens.Name = "cmbPHaveChildrens";
            this.cmbPHaveChildrens.Size = new System.Drawing.Size(260, 22);
            this.cmbPHaveChildrens.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(28, 136);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 14);
            this.label11.TabIndex = 219;
            this.label11.Text = "Have Childrens :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(40, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 14);
            this.label12.TabIndex = 218;
            this.label12.Text = "MaritalStatus :";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.chkPCaste);
            this.groupBox7.Controls.Add(this.pnlPManglik);
            this.groupBox7.Controls.Add(this.label91);
            this.groupBox7.Controls.Add(this.label92);
            this.groupBox7.Location = new System.Drawing.Point(14, 307);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(857, 80);
            this.groupBox7.TabIndex = 264;
            this.groupBox7.TabStop = false;
            // 
            // chkPCaste
            // 
            this.chkPCaste.CheckOnClick = true;
            this.chkPCaste.FormattingEnabled = true;
            this.chkPCaste.Location = new System.Drawing.Point(149, 17);
            this.chkPCaste.Name = "chkPCaste";
            this.chkPCaste.Size = new System.Drawing.Size(260, 55);
            this.chkPCaste.TabIndex = 0;
            // 
            // pnlPManglik
            // 
            this.pnlPManglik.Controls.Add(this.rdbtnPManglikDontKnow);
            this.pnlPManglik.Controls.Add(this.rdbtnPManglikNo);
            this.pnlPManglik.Controls.Add(this.rdbtnPManglikYes);
            this.pnlPManglik.Location = new System.Drawing.Point(587, 14);
            this.pnlPManglik.Name = "pnlPManglik";
            this.pnlPManglik.Size = new System.Drawing.Size(260, 27);
            this.pnlPManglik.TabIndex = 1;
            // 
            // rdbtnPManglikDontKnow
            // 
            this.rdbtnPManglikDontKnow.AutoSize = true;
            this.rdbtnPManglikDontKnow.Location = new System.Drawing.Point(97, 4);
            this.rdbtnPManglikDontKnow.Name = "rdbtnPManglikDontKnow";
            this.rdbtnPManglikDontKnow.Size = new System.Drawing.Size(119, 18);
            this.rdbtnPManglikDontKnow.TabIndex = 2;
            this.rdbtnPManglikDontKnow.TabStop = true;
            this.rdbtnPManglikDontKnow.Text = "Doesn\'t matter";
            this.rdbtnPManglikDontKnow.UseVisualStyleBackColor = true;
            // 
            // rdbtnPManglikNo
            // 
            this.rdbtnPManglikNo.AutoSize = true;
            this.rdbtnPManglikNo.Location = new System.Drawing.Point(52, 4);
            this.rdbtnPManglikNo.Name = "rdbtnPManglikNo";
            this.rdbtnPManglikNo.Size = new System.Drawing.Size(42, 18);
            this.rdbtnPManglikNo.TabIndex = 1;
            this.rdbtnPManglikNo.TabStop = true;
            this.rdbtnPManglikNo.Text = "No";
            this.rdbtnPManglikNo.UseVisualStyleBackColor = true;
            // 
            // rdbtnPManglikYes
            // 
            this.rdbtnPManglikYes.AutoSize = true;
            this.rdbtnPManglikYes.Location = new System.Drawing.Point(3, 4);
            this.rdbtnPManglikYes.Name = "rdbtnPManglikYes";
            this.rdbtnPManglikYes.Size = new System.Drawing.Size(47, 18);
            this.rdbtnPManglikYes.TabIndex = 0;
            this.rdbtnPManglikYes.TabStop = true;
            this.rdbtnPManglikYes.Text = "Yes";
            this.rdbtnPManglikYes.UseVisualStyleBackColor = true;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(518, 20);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(67, 14);
            this.label91.TabIndex = 133;
            this.label91.Text = "Manglik :";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(91, 17);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(53, 14);
            this.label92.TabIndex = 132;
            this.label92.Text = "Caste :";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtAboutPartner);
            this.groupBox5.Location = new System.Drawing.Point(13, 388);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(659, 64);
            this.groupBox5.TabIndex = 270;
            this.groupBox5.TabStop = false;
            // 
            // txtAboutPartner
            // 
            this.txtAboutPartner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAboutPartner.Location = new System.Drawing.Point(25, 16);
            this.txtAboutPartner.Multiline = true;
            this.txtAboutPartner.Name = "txtAboutPartner";
            this.txtAboutPartner.Size = new System.Drawing.Size(622, 39);
            this.txtAboutPartner.TabIndex = 0;
            this.txtAboutPartner.Tag = "nontxtAbout Life Partner";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnAddPhoto);
            this.tabPage4.Controls.Add(this.flMemberPhotos);
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(889, 458);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Photos";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnAddPhoto
            // 
            this.btnAddPhoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddPhoto.FlatAppearance.BorderSize = 0;
            this.btnAddPhoto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddPhoto.Location = new System.Drawing.Point(12, 6);
            this.btnAddPhoto.Name = "btnAddPhoto";
            this.btnAddPhoto.Size = new System.Drawing.Size(95, 34);
            this.btnAddPhoto.TabIndex = 20;
            this.btnAddPhoto.Text = "Add Photo";
            this.btnAddPhoto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddPhoto.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAddPhoto.UseVisualStyleBackColor = true;
            this.btnAddPhoto.Click += new System.EventHandler(this.btnAddPhoto_Click);
            // 
            // flMemberPhotos
            // 
            this.flMemberPhotos.Location = new System.Drawing.Point(8, 43);
            this.flMemberPhotos.Name = "flMemberPhotos";
            this.flMemberPhotos.Size = new System.Drawing.Size(872, 409);
            this.flMemberPhotos.TabIndex = 19;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel4);
            this.tabPage5.Controls.Add(this.panel3);
            this.tabPage5.Location = new System.Drawing.Point(4, 23);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(889, 458);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Membership Details";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lblSrNo);
            this.panel4.Controls.Add(this.btnAddMemberShip);
            this.panel4.Controls.Add(this.txtBankBranch);
            this.panel4.Controls.Add(this.dtpChaqueDate);
            this.panel4.Controls.Add(this.txtChaqueNo);
            this.panel4.Controls.Add(this.ddlPayBy);
            this.panel4.Controls.Add(this.txtAmountReceived);
            this.panel4.Controls.Add(this.label54);
            this.panel4.Controls.Add(this.label55);
            this.panel4.Controls.Add(this.label57);
            this.panel4.Controls.Add(this.label58);
            this.panel4.Controls.Add(this.dtpEndDate);
            this.panel4.Controls.Add(this.updwnMembershipMonth);
            this.panel4.Controls.Add(this.dtpStartDate);
            this.panel4.Controls.Add(this.dtpJoinDate);
            this.panel4.Controls.Add(this.txtMemberShipTypeCode);
            this.panel4.Controls.Add(this.txtMemberShipType);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.label52);
            this.panel4.Controls.Add(this.label53);
            this.panel4.Location = new System.Drawing.Point(13, 7);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(866, 142);
            this.panel4.TabIndex = 0;
            // 
            // lblSrNo
            // 
            this.lblSrNo.AutoSize = true;
            this.lblSrNo.Location = new System.Drawing.Point(365, 107);
            this.lblSrNo.Name = "lblSrNo";
            this.lblSrNo.Size = new System.Drawing.Size(0, 14);
            this.lblSrNo.TabIndex = 341;
            // 
            // btnAddMemberShip
            // 
            this.btnAddMemberShip.Location = new System.Drawing.Point(712, 103);
            this.btnAddMemberShip.Name = "btnAddMemberShip";
            this.btnAddMemberShip.Size = new System.Drawing.Size(94, 31);
            this.btnAddMemberShip.TabIndex = 10;
            this.btnAddMemberShip.Text = "Submit";
            this.btnAddMemberShip.UseVisualStyleBackColor = true;
            this.btnAddMemberShip.Click += new System.EventHandler(this.btnAddMemberShip_Click);
            // 
            // txtBankBranch
            // 
            this.txtBankBranch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBankBranch.Location = new System.Drawing.Point(587, 78);
            this.txtBankBranch.Name = "txtBankBranch";
            this.txtBankBranch.Size = new System.Drawing.Size(260, 22);
            this.txtBankBranch.TabIndex = 9;
            this.txtBankBranch.Tag = "";
            // 
            // dtpChaqueDate
            // 
            this.dtpChaqueDate.CustomFormat = "dd/MM/yyyy";
            this.dtpChaqueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpChaqueDate.Location = new System.Drawing.Point(736, 54);
            this.dtpChaqueDate.Name = "dtpChaqueDate";
            this.dtpChaqueDate.Size = new System.Drawing.Size(111, 22);
            this.dtpChaqueDate.TabIndex = 8;
            // 
            // txtChaqueNo
            // 
            this.txtChaqueNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtChaqueNo.Location = new System.Drawing.Point(587, 54);
            this.txtChaqueNo.Name = "txtChaqueNo";
            this.txtChaqueNo.Size = new System.Drawing.Size(143, 22);
            this.txtChaqueNo.TabIndex = 7;
            this.txtChaqueNo.Tag = "nonnumChequeNo";
            // 
            // ddlPayBy
            // 
            this.ddlPayBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPayBy.FormattingEnabled = true;
            this.ddlPayBy.Items.AddRange(new object[] {
            "Cash",
            "Cheque / DD"});
            this.ddlPayBy.Location = new System.Drawing.Point(587, 29);
            this.ddlPayBy.Name = "ddlPayBy";
            this.ddlPayBy.Size = new System.Drawing.Size(260, 22);
            this.ddlPayBy.TabIndex = 6;
            // 
            // txtAmountReceived
            // 
            this.txtAmountReceived.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAmountReceived.Location = new System.Drawing.Point(587, 5);
            this.txtAmountReceived.Name = "txtAmountReceived";
            this.txtAmountReceived.Size = new System.Drawing.Size(135, 22);
            this.txtAmountReceived.TabIndex = 5;
            this.txtAmountReceived.Tag = "MemberName";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(470, 88);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(113, 14);
            this.label54.TabIndex = 334;
            this.label54.Text = "Bank && Branch :";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(445, 60);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(138, 14);
            this.label55.TabIndex = 333;
            this.label55.Text = "Cheque No. / Date :";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(521, 36);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(62, 14);
            this.label57.TabIndex = 332;
            this.label57.Text = "Pay By :";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(517, 11);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(66, 14);
            this.label58.TabIndex = 331;
            this.label58.Text = "Amount :";
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.CustomFormat = "dd/MM/yyyy";
            this.dtpEndDate.Enabled = false;
            this.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndDate.Location = new System.Drawing.Point(190, 103);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(135, 22);
            this.dtpEndDate.TabIndex = 4;
            // 
            // updwnMembershipMonth
            // 
            this.updwnMembershipMonth.Location = new System.Drawing.Point(190, 78);
            this.updwnMembershipMonth.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.updwnMembershipMonth.Name = "updwnMembershipMonth";
            this.updwnMembershipMonth.Size = new System.Drawing.Size(71, 22);
            this.updwnMembershipMonth.TabIndex = 3;
            this.updwnMembershipMonth.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.updwnMembershipMonth.ValueChanged += new System.EventHandler(this.updwnMembershipMonth_ValueChanged);
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.CustomFormat = "dd/MM/yyyy";
            this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartDate.Location = new System.Drawing.Point(190, 54);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(135, 22);
            this.dtpStartDate.TabIndex = 2;
            // 
            // dtpJoinDate
            // 
            this.dtpJoinDate.CustomFormat = "dd/MM/yyyy";
            this.dtpJoinDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpJoinDate.Location = new System.Drawing.Point(190, 29);
            this.dtpJoinDate.Name = "dtpJoinDate";
            this.dtpJoinDate.Size = new System.Drawing.Size(135, 22);
            this.dtpJoinDate.TabIndex = 1;
            // 
            // txtMemberShipTypeCode
            // 
            this.txtMemberShipTypeCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMemberShipTypeCode.Location = new System.Drawing.Point(429, 5);
            this.txtMemberShipTypeCode.Name = "txtMemberShipTypeCode";
            this.txtMemberShipTypeCode.Size = new System.Drawing.Size(13, 22);
            this.txtMemberShipTypeCode.TabIndex = 329;
            this.txtMemberShipTypeCode.Tag = "*ProfileCreatedByCode";
            this.txtMemberShipTypeCode.Visible = false;
            // 
            // txtMemberShipType
            // 
            this.txtMemberShipType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMemberShipType.Location = new System.Drawing.Point(190, 5);
            this.txtMemberShipType.Name = "txtMemberShipType";
            this.txtMemberShipType.Size = new System.Drawing.Size(237, 22);
            this.txtMemberShipType.TabIndex = 0;
            this.txtMemberShipType.Tag = "%ProfileCreatedBy";
            this.txtMemberShipType.Validated += new System.EventHandler(this.txtMemberShipType_Validated);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 107);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(173, 14);
            this.label13.TabIndex = 127;
            this.label13.Text = "Membership Expired On :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(41, 82);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(145, 14);
            this.label17.TabIndex = 126;
            this.label17.Text = "MemberShip Period :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(53, 58);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(133, 14);
            this.label39.TabIndex = 125;
            this.label39.Text = "Membership Start :";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(108, 34);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(78, 14);
            this.label52.TabIndex = 124;
            this.label52.Text = "Join Date :";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(52, 9);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(134, 14);
            this.label53.TabIndex = 123;
            this.label53.Text = "MemberShip Type :";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dgvMemershipDetails);
            this.panel3.Location = new System.Drawing.Point(13, 154);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(870, 294);
            this.panel3.TabIndex = 21;
            // 
            // dgvMemershipDetails
            // 
            this.dgvMemershipDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMemershipDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMemershipDetails.Location = new System.Drawing.Point(0, 0);
            this.dgvMemershipDetails.Name = "dgvMemershipDetails";
            this.dgvMemershipDetails.Size = new System.Drawing.Size(870, 294);
            this.dgvMemershipDetails.TabIndex = 0;
            this.dgvMemershipDetails.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMemershipDetails_CellClick);
            // 
            // pnlErrorMsg
            // 
            this.pnlErrorMsg.BackColor = System.Drawing.SystemColors.Control;
            this.pnlErrorMsg.Controls.Add(this.picMsg);
            this.pnlErrorMsg.Controls.Add(this.lblMsg);
            this.pnlErrorMsg.Controls.Add(this.btnNext);
            this.pnlErrorMsg.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlErrorMsg.Location = new System.Drawing.Point(0, 572);
            this.pnlErrorMsg.Name = "pnlErrorMsg";
            this.pnlErrorMsg.Size = new System.Drawing.Size(911, 39);
            this.pnlErrorMsg.TabIndex = 2;
            // 
            // picMsg
            // 
            this.picMsg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picMsg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picMsg.Location = new System.Drawing.Point(19, 11);
            this.picMsg.Name = "picMsg";
            this.picMsg.Size = new System.Drawing.Size(16, 16);
            this.picMsg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMsg.TabIndex = 14;
            this.picMsg.TabStop = false;
            // 
            // lblMsg
            // 
            this.lblMsg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblMsg.ForeColor = System.Drawing.Color.Green;
            this.lblMsg.Location = new System.Drawing.Point(49, 3);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(597, 33);
            this.lblMsg.TabIndex = 13;
            this.lblMsg.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(792, 3);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(94, 31);
            this.btnNext.TabIndex = 0;
            this.btnNext.Text = "Next    >>";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // frmMemberMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 611);
            this.Controls.Add(this.pnlErrorMsg);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.Name = "frmMemberMaster";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Member Master";
            this.Activated += new System.EventHandler(this.frmMemberMaster_Activated);
            this.Deactivate += new System.EventHandler(this.frmMemberMaster_Deactivate);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMemberMaster_FormClosed);
            this.Load += new System.EventHandler(this.frmMemberMaster_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmMemberMaster_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.pnlManglik.ResumeLayout(false);
            this.pnlManglik.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSiblingDetails)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.pnlPManglik.ResumeLayout(false);
            this.pnlPManglik.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updwnMembershipMonth)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMemershipDetails)).EndInit();
            this.pnlErrorMsg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picMsg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmbmStatus;
        private System.Windows.Forms.DateTimePicker dtpRegisterDate;
        private System.Windows.Forms.ComboBox cmbisActive;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RadioButton rdbtnMale;
        private System.Windows.Forms.RadioButton rdbtnFemale;
        private System.Windows.Forms.TextBox txtProfileCreatedBy;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.DateTimePicker dtpDateofBirth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMemberName;
        private System.Windows.Forms.Label lblMemberName;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtBloodGroup;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel pnlManglik;
        private System.Windows.Forms.RadioButton rdbtnManglikDontKnow;
        private System.Windows.Forms.RadioButton rdbtnManglikNo;
        private System.Windows.Forms.RadioButton rdbtnManglikYes;
        private System.Windows.Forms.ComboBox ddlHeight;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtSubCaste;
        private System.Windows.Forms.TextBox txtCaste;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.ComboBox ddlLiveChildrenTogether;
        private System.Windows.Forms.ComboBox ddlNoOfChildren;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpTime;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtVisaCountry;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtVisaStatus;
        private System.Windows.Forms.TextBox txtStateCity;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtHomeAddress2;
        private System.Windows.Forms.TextBox txtHomeAddress1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox chkChangePassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtLandlineNo1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtMobileNo1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtEmailID;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox txtSecondaryEmailID;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox txtLandlineNo;
        private System.Windows.Forms.TextBox txtMobileNo;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtOccupationDtls;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtDegree;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtWorkAddress;
        private System.Windows.Forms.TextBox txtOccupation;
        private System.Windows.Forms.TextBox txtEducation;
        private System.Windows.Forms.ComboBox ddlAnnualIncomeCurrency;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.ComboBox ddlAnnualIncome;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel pnlErrorMsg;
        private System.Windows.Forms.PictureBox picMsg;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txtMotherOccupation;
        private System.Windows.Forms.TextBox txtFatherOccupation;
        private System.Windows.Forms.TextBox txtNativePlace;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtMosalPlace;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtMotherName;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtFatherName;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel2;
        private CustomizeGrid dgvSiblingDetails;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtAboutInfo;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtChoice;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.TextBox txtFileNote;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.ComboBox ddlPHeightTo;
        private System.Windows.Forms.ComboBox ddlPAgeTo;
        private System.Windows.Forms.ComboBox ddlPHeightFrom;
        private System.Windows.Forms.ComboBox ddlPAgeFrom;
        private System.Windows.Forms.CheckedListBox chkPWorkingWith;
        private System.Windows.Forms.CheckedListBox chkPOccupation;
        private System.Windows.Forms.CheckedListBox chkPEducation;
        private System.Windows.Forms.CheckedListBox chkPVisaStatus;
        private System.Windows.Forms.CheckedListBox chkPCountryLivingIn;
        private System.Windows.Forms.CheckedListBox chkPMaritalStatus;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.ComboBox ddlPAnnualIncomeCurrency;
        private System.Windows.Forms.ComboBox ddlPAnnualIncome;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbPHaveChildrens;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.CheckedListBox chkPCaste;
        private System.Windows.Forms.Panel pnlPManglik;
        private System.Windows.Forms.RadioButton rdbtnPManglikDontKnow;
        private System.Windows.Forms.RadioButton rdbtnPManglikNo;
        private System.Windows.Forms.RadioButton rdbtnPManglikYes;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtAboutPartner;
        private System.Windows.Forms.Panel panel3;
        private CustomizeGrid dgvMemershipDetails;
        private System.Windows.Forms.ComboBox ddlMobileNo2_Rel;
        private System.Windows.Forms.ComboBox ddlMobileNo1_Rel;
        private System.Windows.Forms.ComboBox ddlMobileNo_Rel;
        private System.Windows.Forms.TextBox txtCasteCode;
        private System.Windows.Forms.TextBox txtBloodGroupCode;
        private System.Windows.Forms.TextBox txtSubCasteCode;
        private System.Windows.Forms.TextBox txtVisaStatusCode;
        private System.Windows.Forms.TextBox txtStateCityCode;
        private System.Windows.Forms.TextBox txtCountryCode;
        private System.Windows.Forms.TextBox txtVisaCountryCode;
        private System.Windows.Forms.TextBox txtWorkingStateCityCode;
        private System.Windows.Forms.TextBox txtOccupationCode;
        private System.Windows.Forms.TextBox txtEducationCode;
        private System.Windows.Forms.ComboBox ddlMaritalStatus;
        private System.Windows.Forms.TextBox txtProfileCreatedByCode;
        private System.Windows.Forms.ComboBox ddlLandlineNo1_Rel;
        private System.Windows.Forms.Button btnSave_MemberDtl;
        private System.Windows.Forms.Button btnSave_FamilyDtl;
        private System.Windows.Forms.Button btnSave_PartnerPref;
        private System.Windows.Forms.Button btnAddPhoto;
        private System.Windows.Forms.FlowLayoutPanel flMemberPhotos;
        private System.Windows.Forms.Label lblMemberCode;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.NumericUpDown updwnMembershipMonth;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpJoinDate;
        private System.Windows.Forms.TextBox txtMemberShipTypeCode;
        private System.Windows.Forms.TextBox txtMemberShipType;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtBankBranch;
        private System.Windows.Forms.DateTimePicker dtpChaqueDate;
        private System.Windows.Forms.TextBox txtChaqueNo;
        private System.Windows.Forms.ComboBox ddlPayBy;
        private System.Windows.Forms.TextBox txtAmountReceived;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button btnAddMemberShip;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label lblSrNo;
        private System.Windows.Forms.ComboBox cmbBirthPlace;
    }
}