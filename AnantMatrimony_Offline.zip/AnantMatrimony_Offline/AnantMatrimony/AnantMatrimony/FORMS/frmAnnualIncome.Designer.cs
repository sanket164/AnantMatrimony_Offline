﻿namespace AnantMatrimony.FORMS
{
    partial class frmAnnualIncome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtAnnualIncome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAnnualIncomeCode = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtAnnualIncomeCode);
            this.panel1.Controls.Add(this.txtAnnualIncome);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(443, 69);
            this.panel1.TabIndex = 0;
            // 
            // txtAnnualIncome
            // 
            this.txtAnnualIncome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAnnualIncome.Location = new System.Drawing.Point(108, 21);
            this.txtAnnualIncome.Name = "txtAnnualIncome";
            this.txtAnnualIncome.Size = new System.Drawing.Size(330, 22);
            this.txtAnnualIncome.TabIndex = 6;
            this.txtAnnualIncome.Tag = "comtxtCountry Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 14);
            this.label1.TabIndex = 5;
            this.label1.Text = "Income Slab :";
            // 
            // txtAnnualIncomeCode
            // 
            this.txtAnnualIncomeCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAnnualIncomeCode.Location = new System.Drawing.Point(425, 21);
            this.txtAnnualIncomeCode.Name = "txtAnnualIncomeCode";
            this.txtAnnualIncomeCode.Size = new System.Drawing.Size(13, 22);
            this.txtAnnualIncomeCode.TabIndex = 134;
            this.txtAnnualIncomeCode.Tag = "";
            this.txtAnnualIncomeCode.Visible = false;
            // 
            // frmAnnualIncome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 92);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmAnnualIncome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Annual Income";
            this.Activated += new System.EventHandler(this.frmAnnualIncome_Activated);
            this.Deactivate += new System.EventHandler(this.frmAnnualIncome_Deactivate);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmAnnualIncome_FormClosed);
            this.Load += new System.EventHandler(this.frmAnnualIncome_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtAnnualIncome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAnnualIncomeCode;
    }
}