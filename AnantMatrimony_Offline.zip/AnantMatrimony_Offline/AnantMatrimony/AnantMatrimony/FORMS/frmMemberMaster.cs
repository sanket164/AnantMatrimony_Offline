﻿using AnantMatrimony.UD_CLASS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AnantMatrimony.MatrimonyDAL;
using AnantMatrimony.AnantProp;
using AnantMatrimony.MatrimonyBAL;

namespace AnantMatrimony.FORMS
{
    public partial class frmMemberMaster : Form, ICommonFunctions
    {
        public static int isActiveStatus;
        public frmMemberMaster()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.ShowIcon = false;
        }

        public enum CI
        {
            Edit = 0,
            Delete,
            SerialNo,
            StartDate,
            MembershipMonth,
            EndDate,
            MemberShipTypeCode,
            MemberShipType,
            AmountReceived,
            PayBy,
            ChequeNo,
            ChequeDate,
            BankDetail,
            EX,
            EX1
        }

        public enum BS
        {
            BroSis = 0,
            Name,
            Occupation,
            MaritalStatus,
            Ex
        }

        EventLogging objEventLoging = new EventLogging();
        Global objGlobal = new Global();
        ToolbarPositions TpLast;
        dbInteraction objDb = new dbInteraction();

        string strMaxId = "";
        string strMasterTable = "tbl_Caste";
        string strSQL = "";
        int Intcout = 0;
        int RowNo = 0;

        int Record_Exist = 0;
        bool isValid = false;
        bool IsEdit = false;
        string strCode = "";
        string strCaste = "", strSubCaste = "", strBloodGrp = "", strCountry = "", strStateCity = "", strVisaStatus = "", strEducation = "", strOccupation = "",
            strProfileCreatedBy = "", strMemberShipType = "";
        DataView dvCaste, dvSubCaste, dvBloodGrp, dvCountry, dvSateCity, dvVisaStatus, dvEducation, dvOccupation, dvProfileCreatedBy, dvMemberShipType;
        DataTable dtMobileNo_Rel, dtMobileNo1_Rel, dtMobileNo2_Rel;


        private void frmMemberMaster_Load(object sender, EventArgs e)
        {
            try
            {
                //this.TpLast = ToolbarPositions.eTPOk;
                //((frmMain)base.MdiParent).setControlState(false, true, this);
                GridDesign(dgvMemershipDetails);
                GridDesignSubblings(dgvSiblingDetails);
                GetHelpList();
                FillCombo();
                dgvSiblingDetails.Rows.Add();

                if (Global.strMemberCode != "")
                {
                    DisplalyData(Global.strMemberCode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_Load() " + ex.ToString());
            }
        }

        private void GetHelpList()
        {
            try
            {
                strBloodGrp = "SELECT BloodGroupCode,BloodGroup FROM tbl_BloodGroup ORDER BY BloodGroup";
                dvBloodGrp = objDb.GetDataView(strBloodGrp);

                strCaste = "SELECT CasteCode,Caste FROM tbl_Caste ORDER BY Caste";
                dvCaste = objDb.GetDataView(strCaste);

                strCountry = "SELECT CountryCode,Country FROM tbl_Country ORDER BY Country";
                dvCountry = objDb.GetDataView(strCountry);

                strEducation = "SELECT EducationCode,Education FROM tbl_Education ORDER BY Education";
                dvEducation = objDb.GetDataView(strEducation);

                //strStateCity = "SELECT StateCityCode,StateCity FROM tbl_StateCity WHERE CountryCode=" + txtCountryCode.Text + " ORDER BY StateCity";
                //dvSateCity = objDb.GetDataView(strStateCity);

                strOccupation = "SELECT OccupationCode,Occupation FROM tbl_Occupation ORDER BY Occupation";
                dvOccupation = objDb.GetDataView(strOccupation);

                strVisaStatus = "SELECT VisaStatusCode,VisaStatus FROM tbl_VisaStatus ORDER BY VisaStatus";
                dvVisaStatus = objDb.GetDataView(strVisaStatus);

                strProfileCreatedBy = "SELECT ProfileCreatedByCode,ProfileCreatedBy FROM tbl_ProfileCreatedBy ORDER BY ProfileCreatedBy";
                dvProfileCreatedBy = objDb.GetDataView(strProfileCreatedBy);
                dtMobileNo_Rel = objDb.GetDataTable(strProfileCreatedBy);
                dtMobileNo1_Rel = objDb.GetDataTable(strProfileCreatedBy);
                dtMobileNo2_Rel = objDb.GetDataTable(strProfileCreatedBy);

                strMemberShipType = " select MembershipTypeCode,MembershipType from tbl_MembershipType ";
                dvMemberShipType = objDb.GetDataView(strMemberShipType);

                //DataSet ds = new DataSet();
                //DataRow drNew = ds.Tables[0].NewRow();
                //drNew["Caste"] = "All";
                //drNew["CasteCode"] = "-1";

                //ds.Tables[0].Rows.InsertAt(drNew, 0);
                //ds.Tables.Add(dvCaste.ToTable());

                chkPCaste.DataSource = dvCaste;
                chkPCaste.DisplayMember = "Caste";
                chkPCaste.ValueMember = "CasteCode";

                chkPEducation.DataSource = dvEducation;
                chkPEducation.DisplayMember = "Education";
                chkPEducation.ValueMember = "EducationCode";

                chkPCountryLivingIn.DataSource = dvCountry;
                chkPCountryLivingIn.DisplayMember = "Country";
                chkPCountryLivingIn.ValueMember = "CountryCode";

                //chkPMaritalStatus

                chkPOccupation.DataSource = dvOccupation;
                chkPOccupation.DisplayMember = "Occupation";
                chkPOccupation.ValueMember = "OccupationCode";

                chkPVisaStatus.DataSource = dvVisaStatus;
                chkPVisaStatus.DisplayMember = "VisaStatus";
                chkPVisaStatus.ValueMember = "VisaStatusCode";

                strSQL = "select MaritalStatusCode,MaritalStatus from tbl_MaritalStatus";
                DataTable dtMaritalStatus = objDb.GetDataTable(strSQL);
                chkPMaritalStatus.DataSource = dtMaritalStatus;
                chkPMaritalStatus.ValueMember = "MaritalStatusCode";
                chkPMaritalStatus.DisplayMember = "MaritalStatus";

                strSQL = "select WorkingWithCode,WorkingWith from tbl_WorkingWith";
                DataTable dtWorkingWith = objDb.GetDataTable(strSQL);
                chkPWorkingWith.DataSource = dtWorkingWith;
                chkPWorkingWith.ValueMember = "WorkingWithCode";
                chkPWorkingWith.DisplayMember = "WorkingWith";

                strSQL = "select distinct BirthPlace from tbl_memberMaster where isnull(BirthPlace,'') !='' order by BirthPlace";
                DataTable dtBirthPlace = objDb.GetDataTable(strSQL);
                cmbBirthPlace.DataSource = dtBirthPlace;
                cmbBirthPlace.DisplayMember = "BirthPlace";
                cmbBirthPlace.ValueMember = "BirthPlace";
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.GetHelpList() " + ex.ToString());
            }
        }

        private void frmMemberMaster_Activated(object sender, EventArgs e)
        {
            try
            {
                //((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                //this.AutoValidate = AutoValidate.EnableAllowFocusChange;
                objGlobal.FocusColor(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_Activated() " + ex.ToString());
            }
        }

        private void frmMemberMaster_Deactivate(object sender, EventArgs e)
        {
            try
            {
                //this.AutoValidate = AutoValidate.Disable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_Deactivate() " + ex.ToString());
            }
        }

        private void frmMemberMaster_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //((frmMain)base.MdiParent).setToolbarPositions(ToolbarPositions.eTPNoAction);
                //((frmMain)base.MdiParent).mnuMemberMaster.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_FormClosed() " + ex.ToString());
            }
        }

        private void txtCaste_Validating(object sender, CancelEventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtCaste, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvCaste, this.strCaste, "Caste", true, this.txtCaste, this.txtCasteCode);
        }

        private void txtCaste_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txtSubCaste_Validating(object sender, CancelEventArgs e)
        {
            if (txtCasteCode.Text != "")
            {
                strSubCaste = "SELECT SubCasteCode,SubCaste FROM tbl_SubCaste WHERE CasteCode=" + txtCasteCode.Text + " ORDER BY SubCaste";
                dvSubCaste = objDb.GetDataView(strSubCaste);
                this.objGlobal.ScreenPosition(this.txtCaste, "0:300");
                this.objGlobal.OpenHelpTxtBox_Validating(this.dvSubCaste, this.strSubCaste, "SubCaste", true, this.txtSubCaste, this.txtSubCasteCode);
            }
        }

        private void txtSubCaste_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txtBloodGroup_Validating(object sender, CancelEventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtBloodGroup, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvBloodGrp, this.strBloodGrp, "BloodGroup", true, this.txtBloodGroup, this.txtBloodGroupCode);
        }

        private void txtBloodGroup_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txtEducation_Validating(object sender, CancelEventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtEducation, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvEducation, this.strEducation, "Education", true, this.txtEducation, this.txtEducationCode);
        }

        private void txtOccupation_Validating(object sender, CancelEventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtOccupation, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvOccupation, this.strOccupation, "Occupation", true, this.txtOccupation, this.txtOccupationCode);
        }

        private void txtWorkAddress_Validating(object sender, CancelEventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtWorkAddress, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvSateCity, this.strStateCity, "StateCity", true, this.txtWorkAddress, this.txtWorkingStateCityCode);
        }

        public void FillCombo()
        {
            try
            {
                strSQL = " SELECT HeightCM,Height FROM tbl_Height ORDER BY HeightCM ";
                DataTable dtHeight = objDb.GetDataTable(strSQL);
                ddlHeight.DataSource = dtHeight;
                ddlHeight.ValueMember = "HeightCM";
                ddlHeight.DisplayMember = "Height";

                ddlPHeightFrom.DataSource = dtHeight;
                ddlPHeightFrom.ValueMember = "HeightCM";
                ddlPHeightFrom.DisplayMember = "Height";

                ddlPHeightTo.DataSource = dtHeight;
                ddlPHeightTo.ValueMember = "HeightCM";
                ddlPHeightTo.DisplayMember = "Height";

                strSQL = "select MaritalStatusCode,MaritalStatus from tbl_MaritalStatus";
                DataTable dtMaritalStatus = objDb.GetDataTable(strSQL);
                ddlMaritalStatus.DataSource = dtMaritalStatus;
                ddlMaritalStatus.ValueMember = "MaritalStatusCode";
                ddlMaritalStatus.DisplayMember = "MaritalStatus";

                strSQL = "SELECT AnnualIncomeCurrencyCode,AnnualIncomeCurrency FROM tbl_AnnualIncomeCurrency ORDER BY AnnualIncomeCurrency";
                DataTable dtAnnualIncomeCurrency = objDb.GetDataTable(strSQL);
                ddlAnnualIncomeCurrency.DataSource = dtAnnualIncomeCurrency;
                ddlAnnualIncomeCurrency.ValueMember = "AnnualIncomeCurrencyCode";
                ddlAnnualIncomeCurrency.DisplayMember = "AnnualIncomeCurrency";

                ddlPAnnualIncomeCurrency.DataSource = dtAnnualIncomeCurrency;
                ddlPAnnualIncomeCurrency.ValueMember = "AnnualIncomeCurrencyCode";
                ddlPAnnualIncomeCurrency.DisplayMember = "AnnualIncomeCurrency";

                strSQL = " SELECT AnnualIncomeCode,AnnualIncome FROM tbl_AnnualIncome ";
                DataTable dtAnnualIncome = objDb.GetDataTable(strSQL);
                ddlAnnualIncome.DataSource = dtAnnualIncome;
                ddlAnnualIncome.ValueMember = "AnnualIncomeCode";
                ddlAnnualIncome.DisplayMember = "AnnualIncome";

                ddlPAnnualIncome.DataSource = dtAnnualIncome;
                ddlPAnnualIncome.ValueMember = "AnnualIncomeCode";
                ddlPAnnualIncome.DisplayMember = "AnnualIncome";

                DataTable dtBornYear = objGlobal.GetYearList(1950, 2018);
                ddlPAgeFrom.DataSource = dtBornYear;
                ddlPAgeFrom.DisplayMember = "Number";
                ddlPAgeFrom.ValueMember = "NValue";

                DataTable dtToBornYear = objGlobal.GetYearList(1950, 2018);
                ddlPAgeTo.DataSource = dtToBornYear;
                ddlPAgeTo.DisplayMember = "Number";
                ddlPAgeTo.ValueMember = "NValue";

                ddlMobileNo_Rel.DataSource = dtMobileNo_Rel;
                ddlMobileNo_Rel.DisplayMember = "ProfileCreatedBy";
                ddlMobileNo_Rel.ValueMember = "ProfileCreatedByCode";

                ddlMobileNo1_Rel.DataSource = dtMobileNo1_Rel;
                ddlMobileNo1_Rel.DisplayMember = "ProfileCreatedBy";
                ddlMobileNo1_Rel.ValueMember = "ProfileCreatedByCode";

                ddlMobileNo2_Rel.DataSource = dtMobileNo2_Rel;
                ddlMobileNo2_Rel.DisplayMember = "ProfileCreatedBy";
                ddlMobileNo2_Rel.ValueMember = "ProfileCreatedByCode";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void funAdd()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(true, true, this);
                this.AutoValidate = AutoValidate.EnableAllowFocusChange;
                this.TpLast = ToolbarPositions.eTPAdd;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                //this.txtProfileCreatedBy.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.funAdd() " + exception.ToString());
            }
        }

        public void funClear()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(false, true, this);
                this.TpLast = ToolbarPositions.eTPOk;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.txtCaste.Focus();
                this.IsEdit = false;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.funClear() " + exception.ToString());
            }
        }

        public void funDelete()
        {
            try
            {
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.funDelete() " + exception.ToString());
            }
        }

        public void funEdit()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(true, false, this);
                this.TpLast = ToolbarPositions.eTPEdit;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                IsEdit = true;
                txtCaste.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.funEdit() " + exception.ToString());
            }
        }

        public void funExit()
        {
            try
            {
                this.TpLast = ToolbarPositions.eTPNoAction;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                base.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.funExit() " + exception.ToString());
            }
        }

        public void funReport()
        {
            try
            {
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.funReport() " + exception.ToString());
            }
        }

        public void funSave()
        {
            try
            {

            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.funSave() " + exception.ToString());
            }
        }

        public void funSearch()
        {
            try
            {

            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.funSearch() " + exception.ToString());
            }
        }

        public void DisplalyData(string strCode)
        {
            try
            {
                int PageCount = 0;

                DataSet dsDataList = new DataSet();
                if (isActiveStatus == 2)
                {
                    tbl_UpdateMemberMasterProp Objtbl_MemberMasterProp = new tbl_UpdateMemberMasterProp();
                    Objtbl_MemberMasterProp.MemberCode = Convert.ToInt32(strCode);

                    tbl_UpdateMemberMasterBAL Objtbl_MemberMasterBAL = new tbl_UpdateMemberMasterBAL();
                    dsDataList = Objtbl_MemberMasterBAL.Select_Data(Objtbl_MemberMasterProp, ref PageCount);
                }
                else
                {
                    tbl_MemberMasterProp Objtbl_MemberMasterProp = new tbl_MemberMasterProp();
                    Objtbl_MemberMasterProp.MemberCode = Convert.ToInt32(strCode);

                    tbl_MemberMasterBAL Objtbl_MemberMasterBAL = new tbl_MemberMasterBAL();
                    dsDataList = Objtbl_MemberMasterBAL.Select_Data(Objtbl_MemberMasterProp, ref PageCount);
                }
                if (dsDataList.Tables[0].Rows.Count == 0)
                {
                    tbl_MemberMasterProp Objtbl_MemberMasterProp = new tbl_MemberMasterProp();
                    Objtbl_MemberMasterProp.MemberCode = Convert.ToInt32(strCode);

                    tbl_MemberMasterBAL Objtbl_MemberMasterBAL = new tbl_MemberMasterBAL();
                    dsDataList = Objtbl_MemberMasterBAL.Select_Data(Objtbl_MemberMasterProp, ref PageCount);
                }

                //this.objGlobal.DisplayFields(this, dsDataList.Tables[0]);

                txtMemberName.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["MemberName"]);

                this.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["ProfileID"]);
                //lblProfileID.Text = "- " + Convert.ToString(dsDataList.Tables[0].Rows[0]["ProfileID"]);

                txtProfileCreatedByCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["ProfileCreatedByCode"]);
                txtProfileCreatedBy.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["ProfileCreatedBy"]);
                dtpRegisterDate.Value = Convert.ToDateTime(dsDataList.Tables[0].Rows[0]["RegisterDate"]);//.ToString("dd/MM/yyyy");

                cmbisActive.SelectedIndex = Convert.ToInt16(dsDataList.Tables[0].Rows[0]["isActive"]);

                if (Convert.ToInt32(dsDataList.Tables[0].Rows[0]["Gender"]) == 0)
                    rdbtnMale.Checked = true;
                else
                    rdbtnFemale.Checked = true;

                dtpDateofBirth.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["DateofBirth"]);
                dtpTime.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["TimeofBirth"]);
                cmbBirthPlace.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["BirthPlace"]);
                //txtMaritalStatusCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["MaritalStatusCode"]);
                ddlMaritalStatus.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["MaritalStatus"]);
                ddlNoOfChildren.SelectedIndex = Convert.ToInt32(dsDataList.Tables[0].Rows[0]["NoOfChildren"]);
                if (Convert.ToString(dsDataList.Tables[0].Rows[0]["LiveChildrenTogether"]) != "")
                {
                    ddlLiveChildrenTogether.SelectedIndex = Convert.ToInt32(dsDataList.Tables[0].Rows[0]["LiveChildrenTogether"]);
                }
                txtHomeAddress1.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["HomeAddress1"]);
                txtHomeAddress2.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["HomeAddress2"]);
                txtAboutInfo.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["AboutInfo"]);
                txtChoice.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Choice"]);
                txtRemarks.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Remarks"]);
                cmbmStatus.SelectedIndex = Convert.ToInt32(dsDataList.Tables[0].Rows[0]["mStatus"]);
                txtFileNote.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["FileNote"]);

                txtCountryCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["CountryCode"]);
                txtCountry.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Country"]);

                txtStateCityCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["StateCityCode"]);
                txtStateCity.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["StateCity"]);

                txtVisaStatusCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["VisaStatusCode"]);
                txtVisaStatus.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["VisaStatus"]);

                txtVisaCountryCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["VisaCountryCode"]);
                txtVisaCountry.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["VisaCountry"]);

                txtMobileNo.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["MobileNo"]);
                txtLandlineNo.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["LandlineNo"]);
                txtMobileNo1.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["MobileNo1"]);
                txtLandlineNo1.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["LandlineNo1"]);
                txtEmailID.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["EmailID"]);
                txtSecondaryEmailID.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["SecondaryEmailID"]);
                txtPassword.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Password"]);

                txtEducationCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["EducationCode"]);
                txtEducation.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Education"]);
                txtDegree.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Degree"]);
                txtOccupationCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["OccupationCode"]);
                txtOccupation.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Occupation"]);
                txtOccupationDtls.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["OccupationDtls"]);
                ddlAnnualIncomeCurrency.SelectedValue = Convert.ToString(dsDataList.Tables[0].Rows[0]["AnnualIncomeCurrency"]);
                ddlAnnualIncome.SelectedValue = Convert.ToString(dsDataList.Tables[0].Rows[0]["AnnualIncome"]);
                txtWorkAddress.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["WorkAddress"]);

                txtCasteCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["CasteCode"]);
                txtCaste.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Caste"]);
                txtSubCasteCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["SubCasteCode"]);
                txtSubCaste.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["SubCaste"]);

                if (Convert.ToInt32(dsDataList.Tables[0].Rows[0]["Manglik"]) == Convert.ToInt32(iManglik.No))
                    rdbtnManglikNo.Checked = true;
                else if (Convert.ToInt32(dsDataList.Tables[0].Rows[0]["Manglik"]) == Convert.ToInt32(iManglik.Yes))
                    rdbtnManglikYes.Checked = true;
                else
                    rdbtnManglikDontKnow.Checked = true;

                txtFatherName.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["FatherName"]);
                txtFatherOccupation.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["FatherOccupation"]);
                txtMotherName.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["MotherName"]);
                txtMotherOccupation.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["MotherOccupation"]);

                txtMosalPlace.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["MosalPlace"]);
                txtNativePlace.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["NativePlace"]);

                ddlHeight.SelectedValue = Convert.ToString(dsDataList.Tables[0].Rows[0]["Height"]);
                txtWeight.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["Weight"]);

                txtBloodGroupCode.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["BloodGroupCode"]);
                txtBloodGroup.Text = Convert.ToString(dsDataList.Tables[0].Rows[0]["BloodGroup"]);
                //grdComboItems.Visible = false;

                PartnerPrefrence(Convert.ToInt32(strCode));
                FillMembershipDetail(Convert.ToInt32(strCode));
                FillSibbling_Details(Convert.ToInt32(strCode));

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtProfileCreatedBy_Validating(object sender, CancelEventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtProfileCreatedBy, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvProfileCreatedBy, this.strProfileCreatedBy, "ProfileCreatedBy", true, this.txtProfileCreatedBy, this.txtProfileCreatedByCode);
        }

        private void txtCountry_Validated(object sender, EventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtCountry, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvCountry, this.strCountry, "Country", true, this.txtCountry, this.txtCountryCode);
            if (txtCountryCode.Text != "")
            {
                strStateCity = "SELECT StateCityCode,StateCity FROM tbl_StateCity WHERE CountryCode=" + txtCountryCode.Text + " ORDER BY StateCity";
                dvSateCity = objDb.GetDataView(strStateCity);
            }
        }

        private void txtStateCity_Validated(object sender, EventArgs e)
        {
            if (txtCountryCode.Text == "")
            {
                MessageBox.Show("Please Select Country", "Country Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCountryCode.Focus();
                return;
            }
            this.objGlobal.ScreenPosition(this.txtStateCity, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvSateCity, this.strStateCity, "StateCity", true, this.txtStateCity, this.txtStateCityCode);
        }

        private void txtVisaStatus_Validated(object sender, EventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtVisaStatus, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvVisaStatus, this.strVisaStatus, "VisaStatus", true, this.txtVisaStatus, this.txtVisaStatusCode);
        }

        private void txtVisaCountry_Validated(object sender, EventArgs e)
        {
            this.objGlobal.ScreenPosition(this.txtVisaCountry, "0:300");
            this.objGlobal.OpenHelpTxtBox_Validating(this.dvCountry, this.strCountry, "Country", true, this.txtVisaCountry, this.txtVisaCountryCode);
        }

        private void ddlLiveChildrenTogether_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void PartnerPrefrence(int MemberCode)
        {
            try
            {
                DataSet dsPDataList = new DataSet();
                if (isActiveStatus == 2)
                {
                    tbl_UpdatePartnersPreferencesProp Objtbl_PartnersPreferencesProp = new tbl_UpdatePartnersPreferencesProp();
                    Objtbl_PartnersPreferencesProp.MemberCode = MemberCode;

                    tbl_UpdatePartnersPreferencesBAL Objtbl_PartnersPreferencesBAL = new tbl_UpdatePartnersPreferencesBAL();
                    dsPDataList = Objtbl_PartnersPreferencesBAL.Select_Data(Objtbl_PartnersPreferencesProp);
                }
                else
                {
                    tbl_PartnersPreferencesProp Objtbl_PartnersPreferencesProp = new tbl_PartnersPreferencesProp();
                    Objtbl_PartnersPreferencesProp.MemberCode = MemberCode;

                    tbl_PartnersPreferencesBAL Objtbl_PartnersPreferencesBAL = new tbl_PartnersPreferencesBAL();
                    dsPDataList = Objtbl_PartnersPreferencesBAL.Select_Data(Objtbl_PartnersPreferencesProp);
                }
                if (dsPDataList.Tables[0].Rows.Count == 0)
                {
                    tbl_PartnersPreferencesProp Objtbl_PartnersPreferencesProp = new tbl_PartnersPreferencesProp();
                    Objtbl_PartnersPreferencesProp.MemberCode = MemberCode;

                    tbl_PartnersPreferencesBAL Objtbl_PartnersPreferencesBAL = new tbl_PartnersPreferencesBAL();
                    dsPDataList = Objtbl_PartnersPreferencesBAL.Select_Data(Objtbl_PartnersPreferencesProp);
                }

                if (dsPDataList.Tables[0].Rows.Count > 0)
                {
                    ddlPAgeFrom.SelectedValue = Convert.ToString(dsPDataList.Tables[0].Rows[0]["AgeFrom"]);
                    ddlPAgeTo.SelectedValue = Convert.ToString(dsPDataList.Tables[0].Rows[0]["AgeTo"]);
                    ddlPHeightFrom.SelectedValue = Convert.ToString(dsPDataList.Tables[0].Rows[0]["HeightFrom"]);
                    ddlPHeightTo.SelectedValue = Convert.ToString(dsPDataList.Tables[0].Rows[0]["HeightTo"]);

                    string[] PartnerData;

                    if (dsPDataList.Tables[0].Rows[0]["MaritalStatus"] != null && Convert.ToString(dsPDataList.Tables[0].Rows[0]["MaritalStatus"]) != "")
                    {
                        PartnerData = Convert.ToString(dsPDataList.Tables[0].Rows[0]["MaritalStatus"]).Split(',');

                        for (int i = 0; i < chkPMaritalStatus.Items.Count; i++)
                        {
                            if (PartnerData.Contains(((System.Data.DataRowView)(chkPMaritalStatus.Items[i])).Row.ItemArray[0].ToString()))
                                chkPMaritalStatus.SetItemCheckState(i, CheckState.Checked);
                            else
                                chkPMaritalStatus.SetItemCheckState(i, CheckState.Unchecked);

                            //Objtbl_PartnersPreferencesProp.MaritalStatus = Convert.ToString(PartnerData);
                        }
                    }
                    else
                    {
                        chkPMaritalStatus.SetItemCheckState(0, CheckState.Checked);
                    }
                    //--------
                    PartnerData = null;

                    if (dsPDataList.Tables[0].Rows[0]["CountryLivingIn"] != null && Convert.ToString(dsPDataList.Tables[0].Rows[0]["CountryLivingIn"]) != "")
                    {
                        PartnerData = Convert.ToString(dsPDataList.Tables[0].Rows[0]["CountryLivingIn"]).Split(',');

                        for (int i = 0; i < chkPCountryLivingIn.Items.Count; i++)
                        {
                            if (PartnerData.Contains(((System.Data.DataRowView)(chkPCountryLivingIn.Items[i])).Row.ItemArray[0].ToString()))
                                chkPCountryLivingIn.SetItemCheckState(i, CheckState.Checked);
                            else
                                chkPCountryLivingIn.SetItemCheckState(i, CheckState.Unchecked);

                            //Objtbl_PartnersPreferencesProp.CountryLivingIn = Convert.ToString(PartnerData);
                        }
                    }
                    else
                    {
                        chkPCountryLivingIn.SetItemCheckState(0, CheckState.Checked);
                    }
                    //--------

                    PartnerData = null;
                    if (dsPDataList.Tables[0].Rows[0]["ResidencyStatus"] != null && Convert.ToString(dsPDataList.Tables[0].Rows[0]["ResidencyStatus"]) != "")
                    {
                        PartnerData = Convert.ToString(dsPDataList.Tables[0].Rows[0]["ResidencyStatus"]).Split(',');

                        for (int i = 0; i < chkPVisaStatus.Items.Count; i++)
                        {
                            if (PartnerData.Contains(((System.Data.DataRowView)(chkPVisaStatus.Items[i])).Row.ItemArray[0].ToString()))
                                chkPVisaStatus.SetItemCheckState(i, CheckState.Checked);
                            else
                                chkPVisaStatus.SetItemCheckState(i, CheckState.Unchecked);

                            //Objtbl_PartnersPreferencesProp.ResidencyStatus = Convert.ToString(PartnerData);
                        }
                    }
                    else
                    {
                        chkPVisaStatus.SetItemCheckState(0, CheckState.Checked);
                    }

                    //--------
                    PartnerData = null;
                    if (dsPDataList.Tables[0].Rows[0]["Education"] != null && Convert.ToString(dsPDataList.Tables[0].Rows[0]["Education"]) != "")
                    {
                        PartnerData = Convert.ToString(dsPDataList.Tables[0].Rows[0]["Education"]).Split(',');

                        for (int i = 0; i < chkPEducation.Items.Count; i++)
                        {
                            if (PartnerData.Contains(((System.Data.DataRowView)(chkPEducation.Items[i])).Row.ItemArray[0].ToString()))
                                chkPEducation.SetItemCheckState(i, CheckState.Checked);
                            else
                                chkPEducation.SetItemCheckState(i, CheckState.Unchecked);

                            //Objtbl_PartnersPreferencesProp.Education = Convert.ToString(PartnerData);
                        }
                    }
                    else
                    {
                        chkPEducation.SetItemCheckState(0, CheckState.Checked);
                    }

                    //--------
                    PartnerData = null;
                    if (dsPDataList.Tables[0].Rows[0]["Occupation"] != null && Convert.ToString(dsPDataList.Tables[0].Rows[0]["Occupation"]) != "")
                    {
                        PartnerData = Convert.ToString(dsPDataList.Tables[0].Rows[0]["Occupation"]).Split(',');

                        for (int i = 0; i < chkPOccupation.Items.Count; i++)
                        {
                            if (PartnerData.Contains(((System.Data.DataRowView)(chkPOccupation.Items[i])).Row.ItemArray[0].ToString()))
                                chkPOccupation.SetItemCheckState(i, CheckState.Checked);
                            else
                                chkPOccupation.SetItemCheckState(i, CheckState.Unchecked);

                            //Objtbl_PartnersPreferencesProp.Occupation = Convert.ToString(PartnerData);
                        }
                    }
                    else
                    {
                        chkPOccupation.SetItemCheckState(0, CheckState.Checked);
                    }

                    //--------
                    PartnerData = null;
                    if (dsPDataList.Tables[0].Rows[0]["WorkingWith"] != null && Convert.ToString(dsPDataList.Tables[0].Rows[0]["WorkingWith"]) != "")
                    {
                        PartnerData = Convert.ToString(dsPDataList.Tables[0].Rows[0]["WorkingWith"]).Split(',');

                        for (int i = 0; i < chkPWorkingWith.Items.Count; i++)
                        {
                            if (PartnerData.Contains(((System.Data.DataRowView)(chkPWorkingWith.Items[i])).Row.ItemArray[0].ToString()))
                                chkPWorkingWith.SetItemCheckState(i, CheckState.Checked);
                            else
                                chkPWorkingWith.SetItemCheckState(i, CheckState.Unchecked);

                            //Objtbl_PartnersPreferencesProp.WorkingWith = Convert.ToString(PartnerData);
                        }
                    }
                    else
                    {
                        chkPWorkingWith.SetItemCheckState(0, CheckState.Checked);
                    }
                    //--------
                    PartnerData = null;
                    if (dsPDataList.Tables[0].Rows[0]["Caste"] != null && Convert.ToString(dsPDataList.Tables[0].Rows[0]["Caste"]) != "")
                    {
                        PartnerData = Convert.ToString(dsPDataList.Tables[0].Rows[0]["Caste"]).Split(',');

                        for (int i = 0; i < chkPCaste.Items.Count; i++)
                        {
                            if (PartnerData.Contains(((System.Data.DataRowView)(chkPCaste.Items[i])).Row.ItemArray[0].ToString()))
                                chkPCaste.SetItemCheckState(i, CheckState.Checked);
                            else
                                chkPCaste.SetItemCheckState(i, CheckState.Unchecked);

                            //Objtbl_PartnersPreferencesProp.Caste = Convert.ToString(PartnerData);
                        }
                    }
                    else
                    {
                        chkPCaste.SetItemCheckState(0, CheckState.Checked);
                    }

                    //--------
                    cmbPHaveChildrens.SelectedValue = Convert.ToInt32(dsPDataList.Tables[0].Rows[0]["HaveChildren"]);
                    ddlPAnnualIncomeCurrency.SelectedValue = Convert.ToInt32(dsPDataList.Tables[0].Rows[0]["AnnualIncomeCurrency"]);
                    ddlPAnnualIncome.SelectedValue = Convert.ToInt32(dsPDataList.Tables[0].Rows[0]["AnnualIncome"]);

                    if (Convert.ToInt32(dsPDataList.Tables[0].Rows[0]["Manglik"]) == Convert.ToInt32(iManglik.No))
                        rdbtnPManglikNo.Checked = true;
                    else if (Convert.ToInt32(dsPDataList.Tables[0].Rows[0]["Manglik"]) == Convert.ToInt32(iManglik.Yes))
                        rdbtnPManglikYes.Checked = true;
                    else
                        rdbtnPManglikDontKnow.Checked = true;

                    txtAboutPartner.Text = Convert.ToString(dsPDataList.Tables[0].Rows[0]["AboutPartner"]);
                }
                else
                {
                    if (rdbtnMale.Checked == true)
                    {
                        ddlPAgeFrom.SelectedValue = dtpDateofBirth.Value.Year;
                        ddlPAgeTo.SelectedValue = dtpDateofBirth.Value.Year + 5;
                    }
                    else
                    {
                        ddlPAgeFrom.SelectedValue = dtpDateofBirth.Value.Year - 5;
                        ddlPAgeTo.SelectedValue = dtpDateofBirth.Value.Year;
                    }

                    chkPMaritalStatus.SetItemCheckState(0, CheckState.Checked);
                    chkPCountryLivingIn.SetItemCheckState(0, CheckState.Checked);
                    chkPVisaStatus.SetItemCheckState(0, CheckState.Checked);
                    chkPEducation.SetItemCheckState(0, CheckState.Checked);
                    chkPOccupation.SetItemCheckState(0, CheckState.Checked);
                    chkPWorkingWith.SetItemCheckState(0, CheckState.Checked);
                    chkPCaste.SetItemCheckState(0, CheckState.Checked);

                    rdbtnPManglikDontKnow.Checked = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FillSibbling_Details(int MemberCode)
        {
            DataSet dsSibbling = new DataSet();
            if (isActiveStatus == 2)
            {
                tbl_UpdateSibblingDetailsProp Objtbl_SibblingDetailsProp = new tbl_UpdateSibblingDetailsProp();
                Objtbl_SibblingDetailsProp.MemberCode = MemberCode;

                tbl_UpdateSibblingDetailsBAL Objtbl_SibblingDetailsBAL = new tbl_UpdateSibblingDetailsBAL();
                dsSibbling = Objtbl_SibblingDetailsBAL.Select_Data(Objtbl_SibblingDetailsProp);

            }
            else
            {
                tbl_SibblingDetailsProp Objtbl_SibblingDetailsProp = new tbl_SibblingDetailsProp();
                Objtbl_SibblingDetailsProp.MemberCode = MemberCode;

                tbl_SibblingDetailsBAL Objtbl_SibblingDetailsBAL = new tbl_SibblingDetailsBAL();
                dsSibbling = Objtbl_SibblingDetailsBAL.Select_Data(Objtbl_SibblingDetailsProp);
            }
            if (dsSibbling.Tables[0].Rows.Count == 0)
            {
                tbl_SibblingDetailsProp Objtbl_SibblingDetailsProp = new tbl_SibblingDetailsProp();
                Objtbl_SibblingDetailsProp.MemberCode = MemberCode;

                tbl_SibblingDetailsBAL Objtbl_SibblingDetailsBAL = new tbl_SibblingDetailsBAL();
                dsSibbling = Objtbl_SibblingDetailsBAL.Select_Data(Objtbl_SibblingDetailsProp);
            }
            if (dsSibbling.Tables[0].Rows.Count > 0)
            {
                dgvSiblingDetails.RowCount = dsSibbling.Tables[0].Rows.Count;
                for (int cnt = 0; cnt < dsSibbling.Tables[0].Rows.Count; cnt++)
                {
                    dgvSiblingDetails[(int)BS.BroSis, cnt].Value = Convert.ToString(dsSibbling.Tables[0].Rows[cnt]["BrotherSister"]);
                    dgvSiblingDetails[(int)BS.MaritalStatus, cnt].Value = Convert.ToString(dsSibbling.Tables[0].Rows[cnt]["MaritalStatus"]);
                    dgvSiblingDetails[(int)BS.Name, cnt].Value = Convert.ToString(dsSibbling.Tables[0].Rows[cnt]["SibblingName"]);
                    dgvSiblingDetails[(int)BS.Occupation, cnt].Value = Convert.ToString(dsSibbling.Tables[0].Rows[cnt]["Occupation"]);
                }
            }
            dgvSiblingDetails.Rows.Add();
        }

        public void GridDesign(DataGridView dgv)
        {
            try
            {
                int index = 0;
                //dgv.TopLeftHeaderCell.Value = "SrNo.";
                //dgv.RowHeadersWidth = 50;
                dgv.RowHeadersVisible = false;
                int btnCounter = 0;
                dgv.AllowUserToAddRows = false;
                dgv.AllowUserToDeleteRows = false;
                dgv.EditMode = DataGridViewEditMode.EditOnEnter;
                DataGridViewTextBoxColumn[] columnArray = new DataGridViewTextBoxColumn[20];
                DataGridViewButtonColumn grdButton;
                string[] strArray = new string[] { 
                "Edit", "Delete","SrNo", "StartDate", "MembershipMonth","EndDate","MemberShipTypeCode", "MemberShipType", "AmountReceived","PayBy","ChequeNo","ChequeDate","BankDetail","Ex","Ex1"
            };
                int[] numArray = new int[] { 
                100, 120,100, 100, 100,0,0, 100, 100, 0, 0,0,0,0,0,0
            };
                for (int i = 0; i < strArray.Length; i++)
                {
                    if (strArray[i] == "Delete" || strArray[i] == "Edit")
                    {
                        grdButton = new DataGridViewButtonColumn();
                        grdButton.HeaderText = strArray[i];
                        grdButton.Width = numArray[i];
                        grdButton.FlatStyle = FlatStyle.Popup;
                        dgv.Columns.Add(grdButton);
                        btnCounter = btnCounter + 1;
                    }
                    else
                    {
                        columnArray[index] = new DataGridViewTextBoxColumn();
                        columnArray[index].HeaderText = strArray[i];
                        columnArray[index].Width = numArray[i];
                        dgv.Columns.Add(columnArray[index]);
                        dgv.Columns[index].SortMode = DataGridViewColumnSortMode.NotSortable;
                        index++;
                    }
                }
                dgv.Columns[(int)CI.EX].Visible = false;
                dgv.Columns[(int)CI.EX1].Visible = false;

                dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft;
                dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft;
                dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft;
                dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft;
                dgv.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
                dgv.EditMode = DataGridViewEditMode.EditOnEnter;
                dgv.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
                dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightSeaGreen;
                dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Verdana", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
                dgv.DefaultCellStyle.ForeColor = Color.Blue;
                dgv.DefaultCellStyle.BackColor = SystemColors.Control;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.GridDesign() " + exception.ToString());
            }
        }

        public void GridDesignSubblings(DataGridView dgv)
        {
            try
            {
                int index = 0;
                //dgv.TopLeftHeaderCell.Value = "SrNo.";
                //dgv.RowHeadersWidth = 50;
                dgv.RowHeadersVisible = false;
                int btnCounter = 0;
                dgv.AllowUserToAddRows = false;
                dgv.AllowUserToDeleteRows = false;
                dgv.EditMode = DataGridViewEditMode.EditOnEnter;
                DataGridViewTextBoxColumn[] columnArray = new DataGridViewTextBoxColumn[20];
                DataGridViewButtonColumn grdButton;
                string[] strArray = new string[] { 
                "Brother/Sister", "Name","Occupation", "MaritalStatus","Ex1"
            };
                int[] numArray = new int[] { 
                200, 150 , 100, 150, 0
            };
                for (int i = 0; i < strArray.Length; i++)
                {
                    columnArray[index] = new DataGridViewTextBoxColumn();
                    columnArray[index].HeaderText = strArray[i];
                    columnArray[index].Width = numArray[i];
                    dgv.Columns.Add(columnArray[index]);
                    dgv.Columns[index].SortMode = DataGridViewColumnSortMode.NotSortable;
                    index++;
                }
                dgv.Columns[(int)BS.Ex].Visible = false;

                dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft;
                dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft;
                dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft;
                dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft;
                dgv.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
                dgv.EditMode = DataGridViewEditMode.EditOnEnter;
                dgv.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
                dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightSeaGreen;
                dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Verdana", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
                dgv.DefaultCellStyle.ForeColor = Color.Blue;
                dgv.DefaultCellStyle.BackColor = SystemColors.Control;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmMemberMaster.GridDesign() " + exception.ToString());
            }
        }

        public void FillMembershipDetail(int MemberCode)
        {
            dgvMemershipDetails.Rows.Clear();
            dgvMemershipDetails.DataSource = null;
            tbl_MembershipMasterProp objtbl_MembershipMasterProp = new tbl_MembershipMasterProp();
            objtbl_MembershipMasterProp.MemberCode = MemberCode;

            tbl_MembershipMasterBAL objtbl_MembershipMasterBAL = new tbl_MembershipMasterBAL();
            DataSet dsData = objtbl_MembershipMasterBAL.Select_Data(objtbl_MembershipMasterProp);

            dgvMemershipDetails.RowCount = dsData.Tables[0].Rows.Count;
            for (int cnt = 0; cnt < dsData.Tables[0].Rows.Count; cnt++)
            {
                dgvMemershipDetails[(int)CI.MembershipMonth, cnt].Value = Convert.ToString(dsData.Tables[0].Rows[cnt]["MembershipMonth"]);
                dgvMemershipDetails[(int)CI.MemberShipType, cnt].Value = Convert.ToString(dsData.Tables[0].Rows[cnt]["MemberShipType"]);
                dgvMemershipDetails[(int)CI.SerialNo, cnt].Value = Convert.ToString(dsData.Tables[0].Rows[cnt]["SerialNo"]);
                dgvMemershipDetails[(int)CI.StartDate, cnt].Value = Convert.ToString(dsData.Tables[0].Rows[cnt]["StartDate"]);
                dgvMemershipDetails[(int)CI.AmountReceived, cnt].Value = Convert.ToString(dsData.Tables[0].Rows[cnt]["AmountReceived"]);
                dgvMemershipDetails[(int)CI.Delete, cnt].Value = "Delete";
                dgvMemershipDetails[(int)CI.Edit, cnt].Value = "Edit";
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (!CheckValidate())
                {
                    return;
                }
                string s = cmbBirthPlace.Text;
                int intMemberCode = 0;
                if (Global.strMemberCode != "")
                {
                    intMemberCode = Convert.ToInt32(Global.strMemberCode);
                    lblMemberCode.Text = Global.strMemberCode.ToString();
                }
                int newIndex = tabMain.SelectedIndex + 1;
                ////1. Member Master Details
                ////2. Family Master Details
                ////3. Partner Prefrence Details
                ////4. Phots Details
                ////5. Membership Details
                bool isMasterSaved = false;
                if (newIndex == 1 || newIndex == 2)
                {
                    isMasterSaved = SaveMember_Details(intMemberCode);
                }
                if (newIndex == 3)
                {
                    isMasterSaved = false;
                    isMasterSaved = SavePartnerPreferences(intMemberCode);
                    if (isMasterSaved)
                    {
                        Delete_UpdateMemberData(intMemberCode);
                    }
                }
                tabMain.SelectedIndex = newIndex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public bool CheckValidate()
        {
            isValid = false;
            try
            {
                if (cmbisActive.SelectedIndex == 2)
                {
                    cmbisActive.SelectedIndex = 1;
                }
                if (cmbmStatus.SelectedIndex == 3 || cmbmStatus.SelectedIndex == 4 || cmbmStatus.SelectedIndex == 5)
                {
                    if (MessageBox.Show("Are you Sure to " + cmbisActive.Text + " Profile", cmbisActive.Text, MessageBoxButtons.YesNo) == DialogResult.No)
                        return false;
                }
                if (txtProfileCreatedBy.Text == "")
                {
                    MessageBox.Show("Please Select Profile Created By", "Profile Created By Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtProfileCreatedBy.Focus();
                    isValid = false;
                    return isValid;
                }
                if (txtCaste.Text == "")
                {
                    MessageBox.Show("Please Select Cast", "Caste Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtCaste.Focus();
                    isValid = false;
                    return isValid;
                }
                if (txtSubCaste.Text == "")
                {
                    MessageBox.Show("Please Select Sub Cast", "SubCaste Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtSubCaste.Focus();
                    isValid = false;
                    return isValid;
                }
                if (txtHomeAddress1.Text.Trim() == "")
                {
                    MessageBox.Show("Please Enter Home Address", "Home Address Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtHomeAddress1.Focus();
                    isValid = false;
                    return isValid;
                }
                if (txtMobileNo.Text == "")
                {
                    MessageBox.Show("Please Enter Mobile Number", "Mobile Number Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMobileNo.Focus();
                    isValid = false;
                    return isValid;
                }
                if (txtEmailID.Text == "")
                {
                    MessageBox.Show("Please Enter Email", "Email Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmailID.Focus();
                    isValid = false;
                    return isValid;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return isValid;
        }

        private bool SaveMember_Details(int MemberCode)
        {
            try
            {
                if (cmbmStatus.SelectedIndex == 3 || cmbmStatus.SelectedIndex == 4 || cmbmStatus.SelectedIndex == 5)
                {
                    if (MessageBox.Show("Are you Sure to " + cmbisActive.Text + " Profile", cmbisActive.Text, MessageBoxButtons.YesNo) == DialogResult.No)
                        return false;
                }

                tbl_MemberMasterProp Objtbl_MemberMasterProp = new tbl_MemberMasterProp();
                Objtbl_MemberMasterProp.MemberCode = MemberCode;
                Objtbl_MemberMasterProp.MemberName = txtMemberName.Text;
                Objtbl_MemberMasterProp.ProfileID = (this.Text == "Member Master" ? "" : this.Text);
                Objtbl_MemberMasterProp.ProfileCreatedBy = Convert.ToInt32(txtProfileCreatedByCode.Text);
                Objtbl_MemberMasterProp.RegisterDate = new DateTime(Convert.ToInt32(dtpRegisterDate.Value.Year), Convert.ToInt32(dtpRegisterDate.Value.Month), Convert.ToInt32(dtpRegisterDate.Value.Day));
                Objtbl_MemberMasterProp.isActive = cmbisActive.SelectedIndex;

                if (rdbtnMale.Checked == true)
                    Objtbl_MemberMasterProp.Gender = 0;
                else
                    Objtbl_MemberMasterProp.Gender = 1;

                Objtbl_MemberMasterProp.DateofBirth = (dtpDateofBirth.Value);
                Objtbl_MemberMasterProp.TimeofBirth = (dtpTime.Value);
                Objtbl_MemberMasterProp.BirthPlace = cmbBirthPlace.Text;
                Objtbl_MemberMasterProp.MaritalStatus = Convert.ToInt32(ddlMaritalStatus.SelectedValue);
                Objtbl_MemberMasterProp.NoOfChildren = Convert.ToInt32(ddlNoOfChildren.SelectedIndex);
                Objtbl_MemberMasterProp.LiveChildrenTogether = Convert.ToBoolean(ddlLiveChildrenTogether.SelectedIndex);
                Objtbl_MemberMasterProp.Height = Convert.ToInt16(ddlHeight.SelectedValue);
                Objtbl_MemberMasterProp.Weight = Convert.ToInt16(txtWeight.Text);
                Objtbl_MemberMasterProp.BloodGroup = Convert.ToInt32(txtBloodGroupCode.Text);
                Objtbl_MemberMasterProp.HomeAddress1 = Convert.ToString(txtHomeAddress1.Text);
                Objtbl_MemberMasterProp.HomeAddress2 = Convert.ToString(txtHomeAddress2.Text);
                Objtbl_MemberMasterProp.VisaStatus = Convert.ToInt32(txtVisaStatusCode.Text);
                Objtbl_MemberMasterProp.VisaCountry = Convert.ToInt32(txtVisaCountryCode.Text);
                Objtbl_MemberMasterProp.Country = Convert.ToInt32(txtCountryCode.Text);
                Objtbl_MemberMasterProp.StateCity = Convert.ToInt32(txtStateCityCode.Text);
                Objtbl_MemberMasterProp.MobileNo = Convert.ToString(txtMobileNo.Text);
                Objtbl_MemberMasterProp.LandlineNo = Convert.ToString(txtLandlineNo.Text);
                Objtbl_MemberMasterProp.MobileNo1 = Convert.ToString(txtMobileNo1.Text);
                Objtbl_MemberMasterProp.LandlineNo1 = Convert.ToString(txtLandlineNo1.Text);
                Objtbl_MemberMasterProp.EmailID = Convert.ToString(txtEmailID.Text);
                //if (chkChangePassword.Checked)
                //{
                Objtbl_MemberMasterProp.Password = txtPassword.Text;
                //}
                Objtbl_MemberMasterProp.SecondaryEmailID = Convert.ToString(txtSecondaryEmailID.Text);
                Objtbl_MemberMasterProp.Caste = Convert.ToInt32(txtCasteCode.Text);
                Objtbl_MemberMasterProp.SubCaste = Convert.ToInt32(txtSubCasteCode.Text);

                Objtbl_MemberMasterProp.FatherName = Convert.ToString(txtFatherName.Text);
                Objtbl_MemberMasterProp.FatherOccupation = txtFatherOccupation.Text;
                Objtbl_MemberMasterProp.MotherName = Convert.ToString(txtMotherName.Text);
                Objtbl_MemberMasterProp.MotherOccupation = txtMotherOccupation.Text;
                Objtbl_MemberMasterProp.MosalPlace = Convert.ToString(txtMosalPlace.Text);
                Objtbl_MemberMasterProp.NativePlace = Convert.ToString(txtNativePlace.Text);

                Objtbl_MemberMasterProp.AboutInfo = Convert.ToString(txtAboutInfo.Text);
                Objtbl_MemberMasterProp.Choice = Convert.ToString(txtChoice.Text);
                Objtbl_MemberMasterProp.Remarks = Convert.ToString(txtRemarks.Text);
                Objtbl_MemberMasterProp.mStatus = cmbmStatus.SelectedIndex;
                Objtbl_MemberMasterProp.FileNote = Convert.ToString(txtFileNote.Text);

                if (rdbtnManglikNo.Checked == true)
                    Objtbl_MemberMasterProp.Manglik = iManglik.No;
                else if (rdbtnManglikYes.Checked == true)
                    Objtbl_MemberMasterProp.Manglik = iManglik.Yes;
                else
                    Objtbl_MemberMasterProp.Manglik = iManglik.Doesnt_Know;

                Objtbl_MemberMasterProp.Education = Convert.ToInt32(txtEducationCode.Text);
                Objtbl_MemberMasterProp.Degree = Convert.ToString(txtDegree.Text);
                Objtbl_MemberMasterProp.Occupation = Convert.ToInt32(txtOccupationCode.Text);
                Objtbl_MemberMasterProp.OccupationDtls = Convert.ToString(txtOccupationDtls.Text);
                Objtbl_MemberMasterProp.WorkingWith = 0;
                Objtbl_MemberMasterProp.WorkingAs = 0;
                Objtbl_MemberMasterProp.WorkAddress = Convert.ToString(txtWorkAddress.Text);
                Objtbl_MemberMasterProp.AnnualIncome = Convert.ToInt32(ddlAnnualIncome.SelectedValue);
                Objtbl_MemberMasterProp.AnnualIncomeCurrency = Convert.ToInt32(ddlAnnualIncomeCurrency.SelectedValue);

                Objtbl_MemberMasterProp.Choice = txtChoice.Text;
                Objtbl_MemberMasterProp.Remarks = txtRemarks.Text;
                Objtbl_MemberMasterProp.mStatus = cmbmStatus.SelectedIndex;
                Objtbl_MemberMasterProp.FileNote = txtFileNote.Text;

                tbl_MemberMasterBAL objtbl_MemberMasterBAL = new tbl_MemberMasterBAL();
                int NewMemCode = objtbl_MemberMasterBAL.InsertUpdate_Data(ref Objtbl_MemberMasterProp);

                Objtbl_MemberMasterProp.NewPassword = txtPassword.Text;
                Objtbl_MemberMasterProp.MemberCode = NewMemCode;

                if (chkChangePassword.Checked == true)
                {
                    objtbl_MemberMasterBAL.ChangePassword(Objtbl_MemberMasterProp);
                }
                Global.strMemberCode = NewMemCode.ToString();
                //Objtbl_MemberMasterProp_Global = Objtbl_MemberMasterProp;
                //Objtbl_MemberMasterProp_Global.MemberCode = NewMemCode;

                this.Text = Objtbl_MemberMasterProp.ProfileID;
                //lblProfileID.Text = "- " + Objtbl_MemberMasterProp.ProfileID;

                string[] toAdd = new string[2];
                toAdd[0] = Objtbl_MemberMasterProp.EmailID;
                toAdd[1] = Objtbl_MemberMasterProp.SecondaryEmailID;

                tbl_SibblingDetailsProp Objtbl_SibblingDetailsProp = new tbl_SibblingDetailsProp();
                Objtbl_SibblingDetailsProp.MemberCode = MemberCode;

                tbl_SibblingDetailsBAL Objtbl_SibblingDetailsBAL = new tbl_SibblingDetailsBAL();
                Objtbl_SibblingDetailsBAL.Delete_Data(Objtbl_SibblingDetailsProp);

                for (int i = 0; i < dgvSiblingDetails.Rows.Count; i++)
                {
                    if (Convert.ToString(dgvSiblingDetails[(int)BS.BroSis, i].Value) != ""
                        && Convert.ToString(dgvSiblingDetails[(int)BS.Name, i].Value) != ""
                        && Convert.ToString(dgvSiblingDetails[(int)BS.Occupation, i].Value) != ""
                        && Convert.ToString(dgvSiblingDetails[(int)BS.MaritalStatus, i].Value) != "")
                    {
                        Objtbl_SibblingDetailsProp.BrotherSister = Convert.ToString(dgvSiblingDetails[(int)BS.BroSis, i].Value);
                        Objtbl_SibblingDetailsProp.SibblingName = Convert.ToString(dgvSiblingDetails[(int)BS.Name, i].Value);
                        Objtbl_SibblingDetailsProp.Occupation = Convert.ToString(dgvSiblingDetails[(int)BS.Occupation, i].Value);
                        Objtbl_SibblingDetailsProp.MaritalStatus = Convert.ToString(dgvSiblingDetails[(int)BS.MaritalStatus, i].Value);

                        Objtbl_SibblingDetailsBAL.InsertUpdate_Data(Objtbl_SibblingDetailsProp);
                    }
                }

                //RegistrationMail(Objtbl_MemberMasterProp.MemberName, Objtbl_MemberMasterProp.ProfileID, Objtbl_MemberMasterProp.Password, toAdd);

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool SavePartnerPreferences(int MemberCode)
        {
            try
            {
                tbl_PartnersPreferencesProp objtbl_PartnersPreferencesProp = new tbl_PartnersPreferencesProp();
                objtbl_PartnersPreferencesProp.MemberCode = MemberCode;

                objtbl_PartnersPreferencesProp.AgeFrom = Convert.ToInt16(ddlPAgeFrom.SelectedValue);
                objtbl_PartnersPreferencesProp.AgeTo = Convert.ToInt16(ddlPAgeTo.SelectedValue);

                objtbl_PartnersPreferencesProp.HeightFrom = Convert.ToInt32(ddlPHeightFrom.SelectedValue);
                objtbl_PartnersPreferencesProp.HeightTo = Convert.ToInt32(ddlPHeightTo.SelectedValue);

                string strPartnerData = "";
                //if (chkPCaste. GetItemCheckState(0) != CheckState.Checked)
                //{
                for (int i = 0; i < chkPCaste.CheckedItems.Count; i++)
                {
                    strPartnerData += ((System.Data.DataRowView)(chkPCaste.CheckedItems[i])).Row.ItemArray[0] + ",";
                }
                strPartnerData = strPartnerData.TrimEnd(',');
                objtbl_PartnersPreferencesProp.Caste = strPartnerData;
                //}
                // ----------

                strPartnerData = "";
                //if (chkPMaritalStatus.GetItemCheckState(0) != CheckState.Checked)
                //{
                for (int i = 0; i < chkPMaritalStatus.CheckedItems.Count; i++)
                {
                    strPartnerData += ((System.Data.DataRowView)(chkPMaritalStatus.CheckedItems[i])).Row.ItemArray[0] + ",";
                }
                strPartnerData = strPartnerData.TrimEnd(',');
                objtbl_PartnersPreferencesProp.MaritalStatus = strPartnerData;
                //}
                // ----------

                if (rdbtnPManglikNo.Checked == true)
                    objtbl_PartnersPreferencesProp.Manglik = 0;
                else if (rdbtnPManglikYes.Checked == true)
                    objtbl_PartnersPreferencesProp.Manglik = 1;
                else
                    objtbl_PartnersPreferencesProp.Manglik = 2;
                // ----------

                strPartnerData = "";
                //if (chkPCountryLivingIn.GetItemCheckState(0) != CheckState.Checked)
                //{
                for (int i = 0; i < chkPCountryLivingIn.CheckedItems.Count; i++)
                {
                    strPartnerData += ((System.Data.DataRowView)(chkPCountryLivingIn.CheckedItems[i])).Row.ItemArray[0] + ",";
                }
                strPartnerData = strPartnerData.TrimEnd(',');
                objtbl_PartnersPreferencesProp.CountryLivingIn = strPartnerData;
                //}// ----------

                strPartnerData = "";
                //if (chkPVisaStatus.GetItemCheckState(0) != CheckState.Checked)
                //{
                for (int i = 0; i < chkPVisaStatus.CheckedItems.Count; i++)
                {
                    strPartnerData += ((System.Data.DataRowView)(chkPVisaStatus.CheckedItems[i])).Row.ItemArray[0] + ",";
                }

                strPartnerData = strPartnerData.TrimEnd(',');
                objtbl_PartnersPreferencesProp.ResidencyStatus = strPartnerData;
                //}// ----------

                strPartnerData = "";
                //if (chkPEducation.GetItemCheckState(0) != CheckState.Checked)
                //{
                for (int i = 0; i < chkPEducation.CheckedItems.Count; i++)
                {
                    strPartnerData += ((System.Data.DataRowView)(chkPEducation.CheckedItems[i])).Row.ItemArray[0] + ",";
                }
                strPartnerData = strPartnerData.TrimEnd(',');
                objtbl_PartnersPreferencesProp.Education = strPartnerData;
                //}// ----------

                strPartnerData = "";
                //if (chkPOccupation.GetItemCheckState(0) != CheckState.Checked)
                //{
                for (int i = 0; i < chkPOccupation.CheckedItems.Count; i++)
                {
                    strPartnerData += ((System.Data.DataRowView)(chkPOccupation.CheckedItems[i])).Row.ItemArray[0] + ",";
                }
                strPartnerData = strPartnerData.TrimEnd(',');
                objtbl_PartnersPreferencesProp.Occupation = strPartnerData;
                //}// ----------

                strPartnerData = "";
                //if (chkPWorkingWith.GetItemCheckState(0) != CheckState.Checked)
                //{
                for (int i = 0; i < chkPWorkingWith.CheckedItems.Count; i++)
                {
                    strPartnerData += ((System.Data.DataRowView)(chkPWorkingWith.CheckedItems[i])).Row.ItemArray[0] + ",";
                }
                strPartnerData = strPartnerData.TrimEnd(',');
                objtbl_PartnersPreferencesProp.WorkingWith = strPartnerData;
                //}
                // ----------
                objtbl_PartnersPreferencesProp.HaveChildren = Convert.ToBoolean(cmbPHaveChildrens.SelectedValue);
                objtbl_PartnersPreferencesProp.AnnualIncome = Convert.ToInt32(ddlPAnnualIncome.SelectedValue);
                objtbl_PartnersPreferencesProp.AnnualIncomeCurrency = Convert.ToInt32(ddlPAnnualIncomeCurrency.SelectedValue);
                objtbl_PartnersPreferencesProp.AboutPartner = txtAboutPartner.Text;

                objtbl_PartnersPreferencesProp.Religion = "";
                objtbl_PartnersPreferencesProp.MotherTongue = "";
                objtbl_PartnersPreferencesProp.SubCaste = "";
                objtbl_PartnersPreferencesProp.Diet = "0";
                objtbl_PartnersPreferencesProp.Smoke = "0";
                objtbl_PartnersPreferencesProp.Drink = "0";
                objtbl_PartnersPreferencesProp.BodyType = "";
                objtbl_PartnersPreferencesProp.Complexion = "";
                objtbl_PartnersPreferencesProp.HealthProblem = "";
                objtbl_PartnersPreferencesProp.StateCity = "";


                tbl_PartnersPreferencesBAL objtbl_PartnersPreferencesBAL = new tbl_PartnersPreferencesBAL();
                objtbl_PartnersPreferencesBAL.InsertUpdate_Data(objtbl_PartnersPreferencesProp);
                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void Delete_UpdateMemberData(int MemberCode)
        {
            try
            {
                tbl_UpdateMemberMasterProp Objtbl_UpdateMemberMasterProp = new tbl_UpdateMemberMasterProp();
                Objtbl_UpdateMemberMasterProp.MemberCode = MemberCode;

                tbl_UpdateMemberMasterBAL Objtbl_UpdateMemberMasterBAL = new tbl_UpdateMemberMasterBAL();
                Objtbl_UpdateMemberMasterBAL.Delete_Data(Objtbl_UpdateMemberMasterProp);
            }
            catch
            {
            }
        }

        private void btnAddPhoto_Click(object sender, EventArgs e)
        {
            try
            {
                //if (PhotoExists >= 3)
                //{
                //    ShowGuidMessage(0, new Exception("Maximum 3 Photos can be uploaded!"));
                //    return;
                //}
                OpenFileDialog opFilePhoto = new OpenFileDialog();
                opFilePhoto.Filter = "Image files (*.jpg, *.png, *.jpeg)|*.jpg;*.jpeg;*.png";

                if (opFilePhoto.ShowDialog() == DialogResult.OK)
                {
                    //List<string> UploadedFilesPath = new List<string>();
                    if (opFilePhoto.FileNames.Length <= 5)
                    {
                        bool SizeErr = false;
                        foreach (string singlefile in opFilePhoto.FileNames)
                        {
                            byte[] b = System.IO.File.ReadAllBytes(singlefile);
                            if (b.Length > 0)
                            {
                                if (b.Length > 500000)
                                {
                                    SizeErr = true;
                                    continue;
                                }
                                int MemberCode = Convert.ToInt32(lblMemberCode.Text);
                                UploadImage(singlefile, MemberCode);

                                //ftpUpload ObjftpUpload = new ftpUpload();
                                //string Result = ObjftpUpload.UploadFile(singlefile, "ftp://mehtainfosoft.com/httpdocs/images/1/" + System.IO.Path.GetFileName(singlefile), "mehtain1", "mehta@123");
                                //if (Result != "")
                                //{
                                //    PictureBox pic = new PictureBox();
                                //    pic.Parent = flMemberPhotos;
                                //    pic.Height = 225;
                                //    pic.Width = 150;
                                //    pic.SizeMode = PictureBoxSizeMode.StretchImage;
                                //    pic.Load("http://www.mehtainfosoft.com/images/1/" + System.IO.Path.GetFileName(singlefile));
                                //    pic.Show();
                                //}
                            }
                        }
                        if (SizeErr)
                            throw new Exception("Problem in uploading one or more file(s)! size are too large. (Limit 500 KB)");
                    }
                    else
                        throw new Exception("Maximum 5 files can be uploaded in profile picture.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public bool ThumbnailCallback()
        {
            return false;
        }

        private void UploadImage(string FName, int MemCode)
        {
            string sSavePath = "";
            string sThumbExtension = "";

            string sFilename = "";

            int intThumbWidth;
            int intThumbHeight;

            try
            {
                // Set constant values
                sSavePath = "ftp://anantmatrimony.com/httpdocs/MemberPhoto/";
                sThumbExtension = "_thumb";
                intThumbWidth = 200;//130;
                intThumbHeight = 272;//175;

                // Check file extension (must be JPG)
                string ext = System.IO.Path.GetExtension(FName).ToLower();
                if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                {
                    MessageBox.Show("The file must have an extension of JPG, JPEG or PNG", "Image Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                sFilename = MemCode + "_" + DateTime.Now.ToString("HHmmssfff"); // System.IO.Path.GetFileName(myFile.FileName);
                string sThumbFile = sFilename + sThumbExtension + ext;
                sFilename = sFilename + ext;

                string SourceFile = System.IO.Path.GetDirectoryName(FName) + "\\" + sFilename;

                byte[] b = System.IO.File.ReadAllBytes(FName);

                System.IO.MemoryStream msImage = new System.IO.MemoryStream(b);
                //--------------- Water Mark Text ----------------------

                Bitmap bmp = new Bitmap(msImage); //op.OpenFile());
                Graphics canvas = null; // Graphics.FromImage(bmp);
                try
                {
                    Bitmap bmpNew = new Bitmap(bmp.Width, bmp.Height);
                    canvas = Graphics.FromImage(bmpNew);
                    canvas.DrawImage(bmp, new Rectangle(0, 0,
    bmpNew.Width, bmpNew.Height), 0, 0, bmp.Width, bmp.Height,
    GraphicsUnit.Pixel);
                    //canvas.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height);
                    bmp = bmpNew;
                }
                catch (Exception ee) // Catch exceptions 
                {
                    MessageBox.Show(ee.Message);
                }
                // Here replace "Text" with your text and you also can assign Font Family, Color, Position Of Text etc. 
                //            canvas.DrawString("ANANT MATRIMONY", new Font("Verdana", 14,
                //FontStyle.Bold), new SolidBrush(Color.Red), (bmp.Width / 2),
                //(bmp.Height / 2));

                //canvas.RotateTransform(0, MatrixOrder.Append);

                canvas.DrawString("ANANT MATRIMONY", new Font("Verdana", 20,
    FontStyle.Bold), new SolidBrush(Color.Beige), 20,
    bmp.Height - 50);

                // Save or display the image where you want. 
                bmp.Save(SourceFile, System.Drawing.Imaging.ImageFormat.Jpeg);

                //-------------------End Water Mark Text--------------------


                Bitmap myBitmap = null;

                ftpUpload ObjftpUpload = new ftpUpload();
                string Result = ObjftpUpload.UploadFile(SourceFile, sSavePath + sFilename, "anantmatrimony", "Mehta@123");
                //string Result = ObjftpUpload.UploadFile(SourceFile, sSavePath, "anantmatrimony", "anant@123");
                if (Result != "")
                {
                    // Check whether the file is really a JPEG by opening it
                    System.Drawing.Image.GetThumbnailImageAbort myCallBack =
                                   new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);

                    myBitmap = new Bitmap(SourceFile);

                    // Save thumbnail and output it onto the webpage
                    System.Drawing.Image myThumbnail
                            = myBitmap.GetThumbnailImage(intThumbWidth,
                                                         intThumbHeight, myCallBack, IntPtr.Zero);

                    myThumbnail.Save(sThumbFile);
                    ftpUpload ObjThumbUpload = new ftpUpload();
                    string ResultThumb = ObjThumbUpload.UploadFile(sThumbFile, sSavePath + sThumbFile, "anantmatrimony", "Mehta@123");
                    //string ResultThumb = ObjThumbUpload.UploadFile(sThumbFile, sSavePath, "anantmatrimony", "anant@123");

                    PictureBox pic = new PictureBox();
                    pic.Parent = flMemberPhotos;
                    pic.Height = 225;
                    pic.Width = 150;
                    pic.SizeMode = PictureBoxSizeMode.StretchImage;
                    pic.Load("http://www.anantmatrimony.com/MemberPhoto/" + sThumbFile);
                    pic.Show();

                    myThumbnail.Dispose();
                    myBitmap.Dispose();

                    SavePhotosDB(sFilename, MemCode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SavePhotosDB(string fileName, int MemCode)
        {
            try
            {
                int TotalPhoto = 0;
                tbl_MemberPhotosProp Objtbl_MemberPhotosProp = new tbl_MemberPhotosProp();
                Objtbl_MemberPhotosProp.MemberCode = MemCode;
                Objtbl_MemberPhotosProp.PhotoFileName = fileName;

                tbl_MemberPhotosBAL Objtbl_MemberPhotosBAL = new tbl_MemberPhotosBAL();
                Objtbl_MemberPhotosBAL.InsertUpdate_Data(Objtbl_MemberPhotosProp, ref TotalPhoto);
                //PhotoExists = TotalPhoto;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddMemberShip_Click(object sender, EventArgs e)
        {
            try
            {
                RowNo = dgvMemershipDetails.Rows.Count;
                if (lblSrNo.Text != "")
                {

                }
                else
                {
                    dgvMemershipDetails.Rows.Add();
                    lblSrNo.Text = RowNo.ToString();
                    dgvMemershipDetails[(int)CI.Edit, RowNo].Value = "Edit";
                    dgvMemershipDetails[(int)CI.Delete, RowNo].Value = "Delete";
                    dgvMemershipDetails[(int)CI.SerialNo, RowNo].Value = lblSrNo.Text;
                    dgvMemershipDetails[(int)CI.StartDate, RowNo].Value = dtpStartDate.Text;
                    dgvMemershipDetails[(int)CI.MembershipMonth, RowNo].Value = updwnMembershipMonth.Value;
                    dgvMemershipDetails[(int)CI.EndDate, RowNo].Value = dtpEndDate.Text;
                    dgvMemershipDetails[(int)CI.MemberShipTypeCode, RowNo].Value = txtMemberShipTypeCode.Text;
                    dgvMemershipDetails[(int)CI.MemberShipType, RowNo].Value = txtMemberShipType.Text;
                    dgvMemershipDetails[(int)CI.AmountReceived, RowNo].Value = txtAmountReceived.Text;
                    dgvMemershipDetails[(int)CI.PayBy, RowNo].Value = ddlPayBy.SelectedValue;
                    dgvMemershipDetails[(int)CI.ChequeNo, RowNo].Value = txtChaqueNo.Text;
                    dgvMemershipDetails[(int)CI.ChequeDate, RowNo].Value = dtpChaqueDate.Text;
                    dgvMemershipDetails[(int)CI.BankDetail, RowNo].Value = txtBankBranch.Text;
                    lblSrNo.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtMemberShipType_Validated(object sender, EventArgs e)
        {
            try
            {
                this.objGlobal.ScreenPosition(this.txtVisaCountry, "0:300");
                this.objGlobal.OpenHelpTxtBox_Validating(this.dvMemberShipType, this.strMemberShipType, "MembershipType", true, this.txtMemberShipType, this.txtMemberShipTypeCode);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updwnMembershipMonth_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                CalculateEndDate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void CalculateEndDate()
        {
            dtpEndDate.Value = dtpStartDate.Value.AddMonths(Convert.ToInt32(updwnMembershipMonth.Value));
        }

        private void frmMemberMaster_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void txtMemberName_Validating(object sender, CancelEventArgs e)
        {
            if (txtMemberName.Text == "")
            {
                MessageBox.Show("Please Enter Member Name", "Member Name Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMemberName.Focus();
                return;
            }
        }

        private void txtHomeAddress1_Validating(object sender, CancelEventArgs e)
        {
            if (txtHomeAddress1.Text == "")
            {
                MessageBox.Show("Please Enter Address 1", "Address 1 Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtHomeAddress1.Focus();
                return;
            }
        }

        private void txtMobileNo_Validating(object sender, CancelEventArgs e)
        {
            if (txtMobileNo.Text == "")
            {
                MessageBox.Show("Please Enter Mobile Number", "Mobile Number Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMobileNo.Focus();
                return;
            }
        }

        private void txtEmailID_Validating(object sender, CancelEventArgs e)
        {
            if (txtEmailID.Text == "")
            {
                MessageBox.Show("Please Enter Email", "Email Validation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmailID.Focus();
                return;
            }
        }

        public void SaveMemebrshipMaster(int MemberCode)
        {
            try
            {
                tbl_MembershipMasterProp objtbl_MembershipMasterProp = new tbl_MembershipMasterProp();
                for (int cnt = 0; cnt < dgvMemershipDetails.Rows.Count; cnt++)
                {
                    if (Convert.ToString(dgvMemershipDetails[(int)CI.MemberShipType, cnt].Value) != "")
                    {
                        objtbl_MembershipMasterProp.MemberCode = MemberCode;
                        objtbl_MembershipMasterProp.SerialNo = Convert.ToInt32(dgvMemershipDetails[(int)CI.MemberShipType, cnt].Value);
                        objtbl_MembershipMasterProp.MemberShipTypeCode = Convert.ToInt32(dgvMemershipDetails[(int)CI.MemberShipTypeCode, cnt].Value);
                        objtbl_MembershipMasterProp.StartDate = dtpStartDate.Value;
                        objtbl_MembershipMasterProp.EndDate = dtpEndDate.Value;
                        objtbl_MembershipMasterProp.MembershipMonth = Convert.ToInt32(updwnMembershipMonth.Value);

                        objtbl_MembershipMasterProp.FacilityCode = "";

                        //objtbl_MembershipMasterProp.AmountReceived = Convert.ToInt32(txtAmount.Text);
                        //objtbl_MembershipMasterProp.PayBy = cmbPayBy.SelectedIndex;
                        //objtbl_MembershipMasterProp.ChequeNo = Convert.ToInt32(txtChaqueNo.Text);
                        //objtbl_MembershipMasterProp.ChequeDate = dtpChaqueDate.Value;
                        //objtbl_MembershipMasterProp.BankDetail = Convert.ToString(txtBankBranch.Text);

                        tbl_MembershipMasterBAL objtbl_MembershipMasterBAL = new tbl_MembershipMasterBAL();
                        objtbl_MembershipMasterBAL.InsertUpdate_Data(objtbl_MembershipMasterProp);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvMemershipDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == (int)CI.Edit)
                {

                }
                else if (e.ColumnIndex == (int)CI.Delete)
                {
                    dgvMemershipDetails.Rows.RemoveAt(e.RowIndex);
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }




    }
}
