﻿namespace AnantMatrimony.FORMS
{
    partial class frmProfileCreatedBy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtProfileCreatedBy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtProfileCreatedBy);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(428, 59);
            this.panel1.TabIndex = 0;
            // 
            // txtProfileCreatedBy
            // 
            this.txtProfileCreatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProfileCreatedBy.Location = new System.Drawing.Point(139, 15);
            this.txtProfileCreatedBy.Name = "txtProfileCreatedBy";
            this.txtProfileCreatedBy.Size = new System.Drawing.Size(271, 22);
            this.txtProfileCreatedBy.TabIndex = 6;
            this.txtProfileCreatedBy.Tag = "comtxtProfileCreatedBy";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 14);
            this.label1.TabIndex = 5;
            this.label1.Text = "ProfileCreatedBy :";
            // 
            // frmProfileCreatedBy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 93);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmProfileCreatedBy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Profile Created By";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtProfileCreatedBy;
        private System.Windows.Forms.Label label1;
    }
}