﻿using AnantMatrimony.UD_CLASS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnantMatrimony.FORMS
{
    public partial class frmAnnualIncomeCurrency : Form, ICommonFunctions
    {
        EventLogging objEventLoging = new EventLogging();
        Global objGlobal = new Global();
        ToolbarPositions TpLast;

        string strMaxId = "";
        string strMasterTable = "tbl_AnnualIncomeCurrency";
        string strSQL = "";
        int Intcout = 0;

        int Record_Exist = 0;
        bool isValid = false;
        bool IsEdit = false;
        string strCode = "";

        public frmAnnualIncomeCurrency()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.ShowIcon = false;
        }

        private void frmAnnualIncomeCurrency_Load(object sender, EventArgs e)
        {
            try
            {
                this.TpLast = ToolbarPositions.eTPOk;
                ((frmMain)base.MdiParent).setControlState(false, true, this);
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funDelete() " + exception.ToString());
            }
        }

        private void frmAnnualIncomeCurrency_Activated(object sender, EventArgs e)
        {
            try
            {
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.AutoValidate = AutoValidate.EnableAllowFocusChange;
                objGlobal.FocusColor(this);
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funDelete() " + exception.ToString());
            }
        }

        private void frmAnnualIncomeCurrency_Deactivate(object sender, EventArgs e)
        {
            try
            {
                this.AutoValidate = AutoValidate.Disable;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funDelete() " + exception.ToString());
            }
        }

        private void frmAnnualIncomeCurrency_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                ((frmMain)base.MdiParent).setToolbarPositions(ToolbarPositions.eTPNoAction);
                ((frmMain)base.MdiParent).mnuAnnualIncomeCurrency.Enabled = true;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funReport() " + exception.ToString());
            }
        }
        public void funAdd()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(true, true, this);
                this.AutoValidate = AutoValidate.EnableAllowFocusChange;
                this.TpLast = ToolbarPositions.eTPAdd;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.txtAnnualIncomeCurrency.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funAdd() " + exception.ToString());
            }
        }

        public void funClear()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(false, true, this);
                this.TpLast = ToolbarPositions.eTPOk;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.txtAnnualIncomeCurrency.Focus();
                this.IsEdit = false;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funClear() " + exception.ToString());
            }
        }

        public void funDelete()
        {
            try
            {
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funDelete() " + exception.ToString());
            }
        }

        public void funEdit()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(true, false, this);
                this.TpLast = ToolbarPositions.eTPEdit;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                IsEdit = true;
                txtAnnualIncomeCurrency.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funEdit() " + exception.ToString());
            }
        }

        public void funExit()
        {
            try
            {
                this.TpLast = ToolbarPositions.eTPNoAction;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                base.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funExit() " + exception.ToString());
            }
        }

        public void funReport()
        {
            try
            {
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funReport() " + exception.ToString());
            }
        }

        public void funSave()
        {
            try
            {
                int Intcout = 0;
                if (checkValidation())
                {
                    tbl_AnnualIncomeCurrencyProp objtbl_AnnualIncome = new tbl_AnnualIncomeCurrencyProp();
                    tbl_AnnualIncomeCurrencyBAL objtbl_AnnualIncomeBAL = new tbl_AnnualIncomeCurrencyBAL();
                    if (IsEdit)
                    {
                        objtbl_AnnualIncome.AnnualIncomeCurrencyCode = Convert.ToInt32(txtAnnualIncomeCurrencyCode.Text);
                        objtbl_AnnualIncome.AnnualIncomeCurrency = txtAnnualIncomeCurrency.Text;
                    }
                    else
                    {
                        objtbl_AnnualIncome.AnnualIncomeCurrencyCode = 0;
                        objtbl_AnnualIncome.AnnualIncomeCurrency = txtAnnualIncomeCurrency.Text;
                    }
                    Intcout = objtbl_AnnualIncomeBAL.InsertUpdate_Data(objtbl_AnnualIncome);
                    if (Intcout > 0)
                    {
                        this.objGlobal.showMessage("AnnualIncomeCurrency", "success", this.IsEdit, this.txtAnnualIncomeCurrency);
                        ((frmMain)base.MdiParent).setToolbarPositions(ToolbarPositions.eTPOk);
                        ((frmMain)base.MdiParent).setControlState(false, true, this);
                        this.TpLast = ToolbarPositions.eTPOk;
                        ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                        this.IsEdit = false;
                    }
                    else
                    {
                        objGlobal.showMessage("AnnualIncomeCurrency", "", IsEdit, txtAnnualIncomeCurrency);
                        txtAnnualIncomeCurrency.Focus();
                    }
                }
                else
                {
                    objGlobal.showMessage("AnnualIncomeCurrency", "", IsEdit, txtAnnualIncomeCurrency);
                    txtAnnualIncomeCurrency.Focus();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funSave() " + exception.ToString());
            }
        }

        public void funSearch()
        {
            try
            {
                tbl_AnnualIncomeCurrencyBAL objbal = new tbl_AnnualIncomeCurrencyBAL();
                tbl_AnnualIncomeCurrencyProp objtbl_tbl_AnnualIncome = new tbl_AnnualIncomeCurrencyProp();
                int PageCount = 0;
                DataSet ds = objbal.Select_Data(objtbl_tbl_AnnualIncome, ref PageCount, 0);
                DataView dvSearch = ds.Tables[0].DefaultView;
                Global.strSearchSqlWidth = " 0:200 ";
                strCode = objGlobal.openSearch(dvSearch);
                if (strCode != "")
                {
                    DisplayRecord(strCode, dvSearch);
                    ((frmMain)this.MdiParent).setControlState(false, false, this);
                    TpLast = ToolbarPositions.eTPDataDisplayed;
                    ((frmMain)this.MdiParent).setToolbarPositions(TpLast);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmBankMaster.funSearch() " + exception.ToString());
            }
        }

        private void DisplayRecord(string Code, DataView dvSearch)
        {
            try
            {
                funClear();
                dvSearch.RowFilter = "";
                dvSearch.RowFilter = "AnnualIncomeCurrencyCode='" + Code + "'";
                if (dvSearch.Count > 0)
                {
                    DataRow row = dvSearch[0].Row;
                    txtAnnualIncomeCurrencyCode.Text = Convert.ToString(row["AnnualIncomeCurrencyCode"]);
                    txtAnnualIncomeCurrency.Text = Convert.ToString(row["AnnualIncomeCurrency"]);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.DisplayRecord() " + exception.ToString());
            }
        }

        private bool checkValidation()
        {
            this.isValid = true;
            try
            {
                if (this.txtAnnualIncomeCurrency.Text == "")
                {
                    MessageBox.Show("Please Insert AnnualIncomeCurrency", "AnnualIncomeCurrency validation", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.isValid = false;
                    this.txtAnnualIncomeCurrency.Focus();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funSave() " + exception.ToString());
            }
            return isValid;
        }
    }
}
