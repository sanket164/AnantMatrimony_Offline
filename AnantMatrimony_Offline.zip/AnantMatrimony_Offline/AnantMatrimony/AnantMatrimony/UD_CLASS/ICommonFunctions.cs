using System;
using System.Collections.Generic;
using System.Text;

namespace AnantMatrimony
{
    interface ICommonFunctions
    {
        void funAdd();
        void funEdit();
        void funSave();
        void funDelete();
        void funSearch();
        void funReport();
        void funClear();
        void funExit();    
         
    }
}
