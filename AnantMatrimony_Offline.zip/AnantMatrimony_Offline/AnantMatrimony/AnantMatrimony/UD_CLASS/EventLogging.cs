﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace AnantMatrimony.UD_CLASS
{
    class EventLogging
    {
        public bool AppErrlog(string error)
        {
            StreamWriter writer = null;
            string str = Convert.ToString(DateTime.Now.ToString("ddMMyyyy"));
            bool flag = File.Exists("C:/ApplicationLog/VasyErrLog/AppLog_" + str + ".txt");
            if (Directory.Exists("C:/ApplicationLog/VasyErrLog"))
            {
                if (flag)
                {
                    writer = new StreamWriter("C:/ApplicationLog/VasyErrLog/AppLog_" + str + ".txt", true);
                    writer.WriteLine(this.WriteInFile(error));
                    writer.Close();
                    return true;
                }
                File.Create("C:/ApplicationLog/VasyErrLog/AppLog_" + str + ".txt").Close();
                writer = new StreamWriter("C:/ApplicationLog/VasyErrLog/AppLog_" + str + ".txt", true);
                writer.WriteLine(this.WriteInFile(error));
                writer.Close();
                return true;
            }
            Directory.CreateDirectory("C:/ApplicationLog/VasyErrLog");
            File.Create("C:/ApplicationLog/VasyErrLog/AppLog_" + str + ".txt").Close();
            writer = new StreamWriter("C:/ApplicationLog/VasyErrLog/AppLog_" + str + ".txt", true);
            writer.WriteLine(this.WriteInFile(error));
            writer.Close();
            return true;
        }
        public string WriteInFile(string error)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("============================================\r\n");
            builder.Append(" \r\n");
            builder.Append("Error Occured At " + DateTime.Now.TimeOfDay.ToString() + "\r\n");
            builder.Append("-----------------------------------------------------\r\n");
            builder.Append(error + "\r\n");
            builder.Append(" \r\n");
            return Convert.ToString(builder);
        }
        //Writes a Database Error to Log file 
        public bool DataBaseErrlog(string error)
        {
            StreamWriter writer = null;
            string str = Convert.ToString(DateTime.Now.ToString("ddMMyyyy"));
            bool flag = File.Exists("C:/ApplicationLog/VasyErrLog/DBLog_" + str + ".txt");
            if (Directory.Exists("C:/ApplicationLog/VasyErrLog"))
            {
                if (flag)
                {
                    writer = new StreamWriter("C:/ApplicationLog/VasyErrLog/DBLog_" + str + ".txt", true);
                    writer.WriteLine(this.WriteInFile(error));
                    writer.Close();
                    return true;
                }
                File.Create("C:/ApplicationLog/VasyErrLog/AppLog_" + str + ".txt").Close();
                writer = new StreamWriter("C:/ApplicationLog/VasyErrLog/DBLog_" + str + ".txt", true);
                writer.WriteLine(this.WriteInFile(error));
                writer.Close();
                return true;
            }
            Directory.CreateDirectory("C:/ApplicationLog/VasyErrLog");
            File.Create("C:/ApplicationLog/VasyErrLog/AppLog_" + str + ".txt").Close();
            writer = new StreamWriter("C:/ApplicationLog/VasyErrLog/DBLog_" + str + ".txt", true);
            writer.WriteLine(this.WriteInFile(error));
            writer.Close();
            return true;
        }


    }
}
