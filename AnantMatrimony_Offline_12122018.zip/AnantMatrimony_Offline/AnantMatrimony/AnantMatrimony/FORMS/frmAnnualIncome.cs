﻿using AnantMatrimony.UD_CLASS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnantMatrimony.FORMS
{
    public partial class frmAnnualIncome : Form, ICommonFunctions
    {
        EventLogging objEventLoging = new EventLogging();
        Global objGlobal = new Global();
        ToolbarPositions TpLast;

        string strMaxId = "";
        string strMasterTable = "tbl_AnnualIncome";
        string strSQL = "";
        int Intcout = 0;

        int Record_Exist = 0;
        bool isValid = false;
        bool IsEdit = false;
        string strCode = "";

        public frmAnnualIncome()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.ShowIcon = false;
        }

        private void frmAnnualIncome_Load(object sender, EventArgs e)
        {
            try
            {
                this.TpLast = ToolbarPositions.eTPOk;
                ((frmMain)base.MdiParent).setControlState(false, true, this);
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funReport() " + exception.ToString());
            }
        }

        private void frmAnnualIncome_Activated(object sender, EventArgs e)
        {
            try
            {
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.AutoValidate = AutoValidate.EnableAllowFocusChange;
                objGlobal.FocusColor(this);
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funReport() " + exception.ToString());
            }
        }

        private void frmAnnualIncome_Deactivate(object sender, EventArgs e)
        {
            try
            {
                this.AutoValidate = AutoValidate.Disable;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funReport() " + exception.ToString());
            }
        }

        private void frmAnnualIncome_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                ((frmMain)base.MdiParent).setToolbarPositions(ToolbarPositions.eTPNoAction);
                ((frmMain)base.MdiParent).mnuAnnualIncome.Enabled = true;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funReport() " + exception.ToString());
            }
        }

        public void funAdd()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(true, true, this);
                this.AutoValidate = AutoValidate.EnableAllowFocusChange;
                this.TpLast = ToolbarPositions.eTPAdd;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.txtAnnualIncome.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funAdd() " + exception.ToString());
            }
        }

        public void funClear()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(false, true, this);
                this.TpLast = ToolbarPositions.eTPOk;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.txtAnnualIncome.Focus();
                this.IsEdit = false;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funClear() " + exception.ToString());
            }
        }

        public void funDelete()
        {
            try
            {
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funDelete() " + exception.ToString());
            }
        }

        public void funEdit()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(true, false, this);
                this.TpLast = ToolbarPositions.eTPEdit;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                IsEdit = true;
                txtAnnualIncome.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funEdit() " + exception.ToString());
            }
        }

        public void funExit()
        {
            try
            {
                this.TpLast = ToolbarPositions.eTPNoAction;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                base.Close();
                IsEdit = true;
                txtAnnualIncome.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funExit() " + exception.ToString());
            }
        }

        public void funReport()
        {
            try
            {
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funReport() " + exception.ToString());
            }
        }

        public void funSave()
        {
            try
            {
                int Intcout = 0;
                if (checkValidation())
                {
                    tbl_AnnualIncomeProp objtbl_AnnualIncome = new tbl_AnnualIncomeProp();
                    tbl_AnnualIncomeBAL objtbl_AnnualIncomeBAL = new tbl_AnnualIncomeBAL();
                    if (IsEdit)
                    {
                        objtbl_AnnualIncome.AnnualIncomeCode = Convert.ToInt32(txtAnnualIncomeCode.Text);
                        objtbl_AnnualIncome.AnnualIncome = txtAnnualIncome.Text;
                    }
                    else
                    {
                        objtbl_AnnualIncome.AnnualIncomeCode = 0;
                        objtbl_AnnualIncome.AnnualIncome = txtAnnualIncome.Text;
                    }
                    Intcout = objtbl_AnnualIncomeBAL.InsertUpdate_Data(objtbl_AnnualIncome);
                    if (Intcout > 0)
                    {
                        this.objGlobal.showMessage("AnnualIncome", "success", this.IsEdit, this.txtAnnualIncome);
                        ((frmMain)base.MdiParent).setToolbarPositions(ToolbarPositions.eTPOk);
                        ((frmMain)base.MdiParent).setControlState(false, true, this);
                        this.TpLast = ToolbarPositions.eTPOk;
                        ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                        this.IsEdit = false;
                    }
                    else
                    {
                        objGlobal.showMessage("AnnualIncome", "", IsEdit, txtAnnualIncome);
                        txtAnnualIncome.Focus();
                    }
                }
                else
                {
                    objGlobal.showMessage("AnnualIncome", "", IsEdit, txtAnnualIncome);
                    txtAnnualIncome.Focus();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funSave() " + exception.ToString());
            }
        }

        public void funSearch()
        {
            try
            {
                tbl_AnnualIncomeBAL objbal = new tbl_AnnualIncomeBAL();
                tbl_AnnualIncomeProp objtbl_tbl_AnnualIncome = new tbl_AnnualIncomeProp();
                int PageCount = 0;
                DataSet ds = objbal.Select_Data(objtbl_tbl_AnnualIncome, ref PageCount, 0);
                DataView dvSearch = ds.Tables[0].DefaultView;
                Global.strSearchSqlWidth = " 0:200 ";
                strCode = objGlobal.openSearch(dvSearch);
                if (strCode != "")
                {
                    DisplayRecord(strCode, dvSearch);
                    ((frmMain)this.MdiParent).setControlState(false, false, this);
                    TpLast = ToolbarPositions.eTPDataDisplayed;
                    ((frmMain)this.MdiParent).setToolbarPositions(TpLast);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.funSearch() " + exception.ToString());
            }
        }

        private void DisplayRecord(string Code, DataView dvSearch)
        {
            try
            {
                funClear();
                dvSearch.RowFilter = "";
                dvSearch.RowFilter = "AnnualIncomeCode='" + Code + "'";
                if (dvSearch.Count > 0)
                {
                    DataRow row = dvSearch[0].Row;
                    txtAnnualIncomeCode.Text = Convert.ToString(row["AnnualIncomeCode"]);
                    txtAnnualIncome.Text = Convert.ToString(row["AnnualIncome"]);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmAnnualIncome.DisplayRecord() " + exception.ToString());
            }
        }

        private bool checkValidation()
        {
            this.isValid = true;
            try
            {
                if (this.txtAnnualIncome.Text == "")
                {
                    MessageBox.Show("Please Insert AnnualIncome", "AnnualIncome validation", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.isValid = false;
                    this.txtAnnualIncome.Focus();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funSave() " + exception.ToString());
            }
            return isValid;
        }
    }
}
