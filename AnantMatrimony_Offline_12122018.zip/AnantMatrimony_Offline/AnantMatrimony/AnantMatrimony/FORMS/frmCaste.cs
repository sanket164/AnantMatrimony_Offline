﻿using AnantMatrimony.UD_CLASS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnantMatrimony.FORMS
{
    public partial class frmCaste : Form, ICommonFunctions
    {
        EventLogging objEventLoging = new EventLogging();
        Global objGlobal = new Global();
        ToolbarPositions TpLast;

        string strMaxId = "";
        string strMasterTable = "tbl_Caste";
        string strSQL = "";
        int Intcout = 0;

        int Record_Exist = 0;
        bool isValid = false;
        bool IsEdit = false;
        string strCode = "";


        public frmCaste()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.ShowIcon = false;
        }

        private void frmCaste_Load(object sender, EventArgs e)
        {
            try
            {
                this.TpLast = ToolbarPositions.eTPOk;
                ((frmMain)base.MdiParent).setControlState(false, true, this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_Load() " + ex.ToString());
            }
        }

        private void frmCaste_Activated(object sender, EventArgs e)
        {
            try
            {
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.AutoValidate = AutoValidate.EnableAllowFocusChange;
                objGlobal.FocusColor(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_Activated() " + ex.ToString());
            }
        }

        private void frmCaste_Deactivate(object sender, EventArgs e)
        {
            try
            {
                this.AutoValidate = AutoValidate.Disable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_Deactivate() " + ex.ToString());
            }
        }

        private void frmCaste_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                ((frmMain)base.MdiParent).setToolbarPositions(ToolbarPositions.eTPNoAction);
                ((frmMain)base.MdiParent).mnuCaste.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_FormClosed() " + ex.ToString());
            }
        }

        private void frmCaste_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.frmCaste_KeyPress() " + ex.ToString());
            }
        }

        public void funAdd()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(true, true, this);
                this.AutoValidate = AutoValidate.EnableAllowFocusChange;
                this.TpLast = ToolbarPositions.eTPAdd;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.txtCaste.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funAdd() " + exception.ToString());
            }
        }

        public void funClear()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(false, true, this);
                this.TpLast = ToolbarPositions.eTPOk;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                this.txtCaste.Focus();
                this.IsEdit = false;
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funClear() " + exception.ToString());
            }
        }

        public void funDelete()
        {
            try
            {
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funDelete() " + exception.ToString());
            }
        }

        public void funEdit()
        {
            try
            {
                ((frmMain)base.MdiParent).setControlState(true, false, this);
                this.TpLast = ToolbarPositions.eTPEdit;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                IsEdit = true;
                txtCaste.Focus();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funEdit() " + exception.ToString());
            }
        }

        public void funExit()
        {
            try
            {
                this.TpLast = ToolbarPositions.eTPNoAction;
                ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                base.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funExit() " + exception.ToString());
            }
        }

        public void funReport()
        {
            try
            {
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funReport() " + exception.ToString());
            }
        }

        public void funSave()
        {
            try
            {
                int Intcout = 0;
                if (checkValidation())
                {
                    tbl_CasteProp objtbl_Caste = new tbl_CasteProp();
                    tbl_CasteBAL objcasteBAL = new tbl_CasteBAL();
                    if (IsEdit)
                    {
                        objtbl_Caste.CasteCode = Convert.ToInt32(txtCasteCode.Text);
                        objtbl_Caste.Caste = txtCaste.Text;
                    }
                    else
                    {
                        objtbl_Caste.CasteCode = 0;
                        objtbl_Caste.Caste = txtCaste.Text;
                    }
                    Intcout = objcasteBAL.InsertUpdate_Data(objtbl_Caste);
                    if (Intcout > 0)
                    {
                        this.objGlobal.showMessage("CASTE", "success", this.IsEdit, this.txtCaste);
                        ((frmMain)base.MdiParent).setToolbarPositions(ToolbarPositions.eTPOk);
                        ((frmMain)base.MdiParent).setControlState(false, true, this);
                        this.TpLast = ToolbarPositions.eTPOk;
                        ((frmMain)base.MdiParent).setToolbarPositions(this.TpLast);
                        this.IsEdit = false;
                    }
                    else
                    {
                        objGlobal.showMessage("CASTE", "", IsEdit, txtCaste);
                        txtCaste.Focus();
                    }
                }
                else
                {
                    objGlobal.showMessage("CASTE", "", IsEdit, txtCaste);
                    txtCaste.Focus();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funSave() " + exception.ToString());
            }
        }

        private bool checkValidation()
        {
            this.isValid = true;
            try
            {
                if (this.txtCaste.Text == "")
                {
                    MessageBox.Show("Please Insert Caste", "Caste validation", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    this.isValid = false;
                    this.txtCaste.Focus();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funSave() " + exception.ToString());
            }
            return isValid;
        }

        public void funSearch()
        {
            try
            {
                tbl_CasteBAL objbal = new tbl_CasteBAL();
                tbl_CasteProp objtbl_Caste = new tbl_CasteProp();
                int PageCount = 0;
                DataSet ds = objbal.Select_Data(objtbl_Caste, 0, ref PageCount);
                DataView dvSearch = ds.Tables[0].DefaultView;
                Global.strSearchSqlWidth = " 0:200 ";
                strCode = objGlobal.openSearch(dvSearch);
                if (strCode != "")
                {
                    DisplayRecord(strCode, dvSearch);
                    ((frmMain)this.MdiParent).setControlState(false, false, this);
                    TpLast = ToolbarPositions.eTPDataDisplayed;
                    ((frmMain)this.MdiParent).setToolbarPositions(TpLast);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.funSearch() " + exception.ToString());
            }
        }

        public void DisplayRecord(string Code, DataView dvSearch)
        {
            try
            {
                funClear();
                dvSearch.RowFilter = "";
                dvSearch.RowFilter = "CasteCode='" + Code + "'";
                if (dvSearch.Count > 0)
                {
                    DataRow row = dvSearch[0].Row;
                    txtCaste.Text = Convert.ToString(row["Caste"]);
                    txtCasteCode.Text = Convert.ToString(row["CasteCode"]);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(Convert.ToString(exception.Message));
                this.objEventLoging.AppErrlog("Error In AnantMatrimony.frmCaste.DisplayRecord() " + exception.ToString());
            }
        }


    }
}
